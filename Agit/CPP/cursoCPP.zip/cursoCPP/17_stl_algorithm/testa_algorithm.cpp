#include <iostream>
#include <list>
#include <vector>
#include <string>
#include <set>

#include <algorithm>
#include <iterator>

void Testa_for_each();  
void Testa_find();
void Testa_sort_e_binary_search();
void Testa_copy();
void Testa_outros();

int main()
{	
	Testa_for_each()			;  std::cout << std::endl;
	Testa_find()				;  std::cout << std::endl;
	Testa_sort_e_binary_search();  std::cout << std::endl;
	Testa_copy()				;  std::cout << std::endl;
	Testa_outros()			;  std::cout << std::endl;

	std::cout << "veja o 'help' de <algorithm> "
		 << "para outras funcoes: "
		<<"(copy_unique, unique, next_permutation,"
		<< "prev_permutation, merge, replace, remove,"
		<< "rotate, etc...)" 
		<< std::endl;

	return 0;
}

// ================================================
// **** Testa_for_each

// usa 'cout_func': fun��o que ser� chamada por 'for_each'
// para imprimir cada elemento de um conjunto (list, vector, etc);
// admite qualquer tipo suportado por 'cout'
template <typename T> inline void cout_func( const T & value )
{
	std::cout << value << "; " ;
}

//*** FOR_EACH: percorre um conjunto, e para cada elemento do conjunto
				// chama a fun��o passada como argumento;
void Testa_for_each()
{
	std::cout << "=========== TESTA for_each\n" << std::endl;
	std::cout << "*** list<int>: " ;
	std::list<int> li;
	std::list<int>::iterator liIt; 
	li.push_back(1); li.push_back(2); li.push_back(3);
		
	std::cout << "for_each: ";
	std::for_each( li.begin(), li.end(), cout_func<int> );
	std::cout << std::endl;

	std::cout << "*** vector<int>: ";
	std::vector<int> vi;
	std::vector<int>::iterator viIt;
	vi.reserve(3);
	vi.push_back(1); vi.push_back(2); vi.push_back(3);

	std::cout << "for_each: ";
	std::for_each( vi.begin(), vi.end(), cout_func<int> );
	std::cout << std::endl;

	std::cout << "*** vector<double>: ";
	std::vector<double> vd;
	std::vector<double>::iterator vdIt;
	vd.push_back(1.1); vd.push_back(2.1); vd.push_back(3.1);

	std::cout << "for_each: ";
	std::for_each( vd.begin(), vd.end(), cout_func<double> );
	std::cout << std::endl;
	
	std::cout << "*** set<string>: " ;
	std::set<std::string> sst;
	std::set<std::string>::iterator sstIt;
	sst.insert("GHI"); sst.insert("DEF"); sst.insert("ABC");

	std::cout << "for_each: ";
        std::for_each( sst.begin(), sst.end(),
                                                cout_func< std::string > );
	std::cout << std::endl ;
}

// ================================================
// **** Testa_find

//*** FIND: procura sequencialmente em um conjunto desordenado ;
void Testa_find()
{
	std::cout << "=========== TESTA find\n" << std::endl;

	std::cout << "*** list<int>: find: ";
	std::list<int> li;
	std::list<int>::iterator liIt; 
	li.push_back(1); li.push_back(2); li.push_back(3);
	
	liIt = std::find (li.begin(), li.end(), 2); // busca 2
	if ( liIt != li.end() )
		std::cout << "localizado: " << *liIt << std::endl;
	
	std::cout << "*** vector<int>: find: " ;
	std::vector<int> vi;
	std::vector<int>::iterator viIt;
	vi.reserve(10);
	vi.push_back(1); vi.push_back(2); vi.push_back(3);

	viIt = std::find (vi.begin(), vi.end(), 2); // busca 2
	if ( viIt != vi.end() )
		std::cout << "localizado: " << *viIt << std::endl;

	std::cout << "*** vector<double>: find: " ;
	std::vector<double> vd;
	std::vector<double>::iterator vdIt;
	vd.push_back(1.1); vd.push_back(2.1); vd.push_back(3.1);

	vdIt = std::find (vd.begin(), vd.end(), 3.1); // busca 3.1
	if ( vdIt != vd.end() )
		std::cout << "localizado: " << *vdIt << std::endl;
	
	std::cout << "*** set<string>: find: " ;
	std::set<std::string> sst;

        // default (ordem crescente):
//        std::set<std::string, std::less<int> > sst_2;
        // ordem decrescente:
        // std::set<std::string, std::greater<int> > sst_3;

        std::set<std::string>::iterator sstIt;
	sst.insert("GHI"); sst.insert("DEF"); sst.insert("ABC");

	// ATEN��O: vai buscar do primeiro at� o �ltimo,
	// sequencialmente, em uma �rvore bin�ria ???
	sstIt = std::find (sst.begin(), sst.end(), "DEF"); // busca "DEF"
	if ( sstIt != sst.end() )
		std::cout << "localizado: " << *sstIt << std::endl;
	// ATEN��O: no caso de set, map e outros conjuntos naturalmente ordenados 
	// USAR a "find" do pr�pio set ou do map...
	sstIt = sst.find( "DEF" ); // busca "DEF"
	if ( sstIt != sst.end() )
		std::cout << "--- localizado MAIS RAPIDAMENTE (set::find): " 
									<< *sstIt << std::endl;
}

// ================================================
// **** Testa_sort_e_binary_search
// usar� ordena��o crescente e decrescente (e busca bin�ria) oferecidos pela STL;
// e usar� tamb�m 'my_lesser': fun��o que ser� chamada por 'sort' e 'binary_search'
// para classificar elementos de forma PERSONALIZADA ;
// neste exemplo, o sinal ser� desprezado:
template <typename T> bool my_lesser ( T elem1, T elem2 )
{ // pode ser usado por qualquer tipo que tenha os operadores '<' e '-'
   if (elem1 < 0)  elem1 = -elem1;
   if (elem2 < 0)  elem2 = -elem2;
   return elem1 < elem2;
}

//*** BINARY_SEARCH: busca bin�ria em um conjunto ordenado ap�s um SORT;
//		OBS: Em �rvores bin�rias e outros conjuntos SEMPRE ORDENADOS, 
//		onde um "sort" N�O se aplica, USAR "find" da pr�pria �rvore (set, map, etc).
void Testa_sort_e_binary_search()
{
	std::cout << "=========== TESTA sort e binary_search\n" << std::endl;

	std::list<int> li;
	std::list<int>::iterator liIt; 

	li.push_back( 50 ); li.push_back( 10 ); li.push_back( 30 ); 
	li.push_back( 20 ); li.push_back( 25 ); li.push_back( 5 );

	li.sort( );  // ordenar: ficar� ordenado AT� que ocorra um novo insert,
					 // ao contr�rio de �rvores bin�rias e outros conjuntos SEMPRE ordenados
        // o default para predicao � "less:
        // li.sort(std::less<int>());

        std::cout << "*** list<int>: apos list<>::sort:  " ;
	std::for_each( li.begin(), li.end(), cout_func<int> );
	std::cout << std::endl;

	// ao contr�rio de 'find' (uma busca sequencial em conjunto desordenado), 
	// 'binary_search' faz uma busca bin�ria 
	// em um conjunto previamente ordenado (com sort):
	if ( binary_search( li.begin( ), li.end( ), 10 ) ) // busca 10
		std::cout << "*** list<int>: binary_search: localizado: 10" << std::endl;

	// usando o predicado 'greater'  para classificar em ordem descendente
	li.sort ( std::greater<int>( ) );
	std::cout << "*** list<int>: apos list<>::sort (greater):  " ;
	std::for_each( li.begin(), li.end(), cout_func<int> );
	std::cout << std::endl;
	// busca 10:
	if ( std::binary_search( li.begin( ), li.end( ), 10 , 
																std::greater<int> ( ) ) )
		std::cout << "*** list<int>: binary_search(greater): localizado: 10"  << std::endl;

	// binary_search usando uma ordena��o personalizada (fun��o 'my_lesser')
	// a qual despreza o sinal na ordena��o (ver essa fun��o logo acima desta)
	std::vector <int> vi;
	std::vector <int>::iterator viIt;
	int i;
	vi.reserve(5);
	for ( i = -2 ; i <= 2 ; i++ ) // insere negativos e positivos...
		vi.push_back( i );

	// usa fun��o 'my_lesser' para as compara��es que 
	// ir�o definir o m�todo de ordena��o:
	std::sort ( vi.begin ( ) , vi.end ( ) , my_lesser<int> );

	std::cout << "*** vector<int>: apos std::sort(personalizado:my_lesser):  " ;
	std::for_each( vi.begin(), vi.end(), cout_func<int> );
	std::cout << std::endl;
	// busca -1:
	if ( binary_search( vi.begin( ), vi.end( ), -1 , my_lesser<int> ) )
		std::cout << "*** vector<int>: binary_search(my_lesser): localizado: -1" << std::endl;
}
// ================================================
// **** Testa_copy
void Testa_copy()
{
	std::cout << "=========== TESTA copy\n" << std::endl;

	std::vector<int> vi1(3,0);  // dimens�o, valor-de-inicializa��o
	std::vector<int> vi2(3,1);  // idem
	std::vector<int>::iterator viIt;

	std::cout << "percorrendo vi1:" << std::endl;
	std::for_each ( vi1.begin(), vi1.end(), cout_func<int>  ); 
	std::cout << std::endl;

	std::cout << "percorrendo vi2:" << std::endl;
	std::for_each ( vi2.begin(), vi2.end(), cout_func<int>  ); 
	std::cout << std::endl;

	// copia o vector "vi1" para o vector "vi2":
        std::copy ( vi1.begin(), vi1.end(), vi2.begin() );

	std::cout << "percorrendo vi2 APOS copy de vi1 para vi2:" << std::endl;
	std::for_each ( vi2.begin(), vi2.end(), cout_func<int>  ); 
	std::cout << std::endl;
	
	// copia o vetor para a sa�da padr�o:
	std::cout << "imprimindo vi2 com copy de vi2 para saida padrao:" << std::endl;
	std::copy ( vi1.begin(), vi1.end(), 
                std::ostream_iterator<int>(std::cout, "; ") );
			// ostream_iterator: exige #include <iterator>

	std::cout << std::endl;
}

// ================================================
// **** Testa_outros
//		  swap, max, min ...
void Testa_outros()
{
	std::cout << "=========== TESTA outros...\n" << std::endl;

	int x = 4 , y = 5 ;
	std::cout << "*** swap:  [" << "x = " << x << " , y = " << y << "] ";
	std::swap ( x, y );
	std::cout << "  - apos swap:  x = " << x << " ; y  = " << y << std::endl;

	std::cout << "*** max e min:  [" << x << " , " << y << "] " 
				  << "  - max = " << std::max(x,y) 
		           << "  ;  min = " << std::min(x,y) << std::endl;
}


