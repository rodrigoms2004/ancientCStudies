/* arquivo data.c */

/* Em primeiro lugar, precisamos incluir os arquivos 
   onde est�o declarados:
	1)	a fun��o "printf", que ser� usada em "Imprime"
	2)	a estrutura "Data", 
		os prot�tipos para as fun��es especializadas em "Data" e
		os demais recursos (typedef e #define) usados pela estrutura
		ou pelas fun��es:
*/

#include <stdio.h>  /* para "printf" */
#include "data.h"   /* para a estrutura "Data"... */


/*	atribui valores "default" 
	para os campos de controle: 
*/
void Inicia( Data * pdtParam ) 
{
	pdtParam->m_shAnoMin  = ANO_MIN_DEF ;
	pdtParam->m_shAnoMax = ANO_MAX_DEF ;

	pdtParam->m_bOK = FALSE;  /* << esta vari�vel do tipo "Data" ainda n�o tem 
								  valores v�lidos para dia, m�s ou ano; 
								  ent�o deve ser assinalada como inv�lida 
							 */
}


/* alterar uma vari�vel do tipo Data: 
*/
void Altera ( Data * pdtParam, char cDia, char cMes, short shAno )
{
	pdtParam->m_cDia  = cDia ;
	pdtParam->m_cMes  = cMes;
	pdtParam->m_shAno = shAno;

	/* an�lise e valida��o dos valores recebidos
		(obs:	na vers�o em C++ faremos a an�lise correta 
				do �ltimo dia de cada m�s; 
				aqui ser� usado apenas "31" para todos os meses): 
	*/
	if (  pdtParam->m_shAno >= pdtParam->m_shAnoMin  &&    /* and */
		   pdtParam->m_shAno <= pdtParam->m_shAnoMax && 
		   pdtParam->m_cMes >= 1 && pdtParam->m_cMes <= 12 && 
		   pdtParam->m_cDia  >= 1 && pdtParam->m_cDia <= 31 )
	{
		pdtParam->m_bOK = TRUE;    /* valores corretos */
	}
	else
	{
		pdtParam->m_bOK = FALSE;    /* valores incorretos */
	}
}

/* imprimir uma vari�vel do tipo Data: 
*/
void Imprime ( const Data * pdtParam )
{
	// error C2166: l-value specifies const object
	// pdtParam->m_bOK = FALSE ;
	// Acima, ERRO: tentando alterar objeto declarado como 
	// "const" ("read-only").

	if ( pdtParam->m_bOK ) /* se a vari�vel estiver v�lida, imprime os campos: */
	{
		printf ( "%02d/%02d/%04d\n" ,
					pdtParam->m_cDia  , 
					pdtParam->m_cMes , 
					pdtParam->m_shAno ) ;
	}
	else /* os dados est�o incorretos; ent�o imprime uma mensagem de erro: */
	{
		printf("??:??:????\n");
	}
}
