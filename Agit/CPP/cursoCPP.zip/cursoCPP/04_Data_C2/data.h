/* arquivo data.h */

typedef int BOOL;  /* cria um sin�nimo para int, a ser usado em "flag's "*/
#define FALSE 0  
#define TRUE  1

/* padroniza constantes para os valores "default" de ano m�nimo e ano m�ximo :*/
#define ANO_MIN_DEF  0
#define ANO_MAX_DEF 9999


/* Agora vamos declarar a estrutura, tipificando cada um dos seus campos. 
No caso, todos os campos ser�o n�meros inteiros.
Contudo usaremos tipos diferentes de modo que cada campo utilize o menor n�mero de bytes poss�vel de acordo com suas necessidades.
Por exemplo: o "dia" de uma "Data" pode variar de 1 a 31; ent�o ele s� precisa de um �nico byte. Idem para "m�s"(de 1 a 12). 
Para "ano" precisaremos de dois bytes (de forma a permitir varia��es de zero at�, pelo menos, 9999).
Para conhecer os tipos primitivos suportados pela linguagem, e seus respectivos intervalos de valores, voc� pode ver agora a Tabela 1(Tabela de Tipos) no "Guia de Refer�ncia R�pida", ao final da apostila.
*/
struct _Data
{	
	/* atributos principais: */
	char	m_cDia;
	char	m_cMes;
	short	m_shAno;

	/* campos para valida��o ou c�lculo: */
	short	m_shAnoMin , m_shAnoMax;    /* campos para valida��o do ano */
	int		m_iDiaCorrido;   /* campo para c�lculo de diferen�as entre datas */
	BOOL	m_bOK;    /* flag para indicar se a data est� correta */
};

typedef   struct _Data   Data  ;  /* sin�nimo para simplificar o uso�*/

/*	Abaixo, ser� escrito o prot�tipo da fun��o "Inicia", que servir� para iniciar a atribui��o de alguns ou de todos os campos de uma Data com valores "default".
	Ela funcionar� do seguinte modo:
	1) receber�, como par�metro, o endere�o de uma vari�vel do tipo Data;
	2) em seguida alterar�, a partir do endere�o, alguns campos da mem�ria por ele apontada;
*/
void Inicia( Data * pdtParam ) ;

/* Uso t�pico da fun��o prototipada acima:
	int main()
	{
		Data Hoje ;
		Inicia( &Hoje );  // passa o endere�o da vari�vel do tipo "Data"
		..............
	}
*/

/*	fun��o para alterar os campos m�s, dia e ano de uma vari�vel do tipo Data,
	cujo ENDERE�O ser� passado para pdtParam
*/
void Altera ( Data * pdtParam, char cDia, char cMes, short shAno );
/* receber� tr�s valores que dever�o ser atribu�dos aos campos
		 m_cDia, m_cMes e m_shAno, respectivamente. */

/*	fun��o para imprimir uma vari�vel do tipo Data,
	a partir do endere�o que � recebido aqui:
 */
void Imprime ( const Data * pdtParam );

/*
E isso � tudo, por enquanto. 
Na realidade, precisar�amos de mais fun��es. 
Mas deixaremos para desenvolver a estrutura "Data" 
de modo completo j� em C++.

Sim, porque s� em C++ teremos um modo simples e direto
de tornar OBRIGAT�RIO o uso das fun��es especializadas, impedindo realmente que os campos recebam valores sem valida��o.
*/
