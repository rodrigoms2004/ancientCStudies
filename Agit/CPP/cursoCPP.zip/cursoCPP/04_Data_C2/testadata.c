/* arquivo testadata.c */

/*  Em primeiro lugar, 
	precisamos incluir os arquivos <stdio.h> e "data.h".
*/
#include <stdio.h>  /* para "printf" */
#include "data.h"   /* para a estrutura "Data"... */

int main()
{
	/* declara duas vari�veis do tipo "Data":  */
	Data dtHoje;
	Data dtPagamento;
	
	/* inicia corretamente antes de usar: */
	Inicia( &dtHoje );
	/* e imprimir� mensagem de erro, 
	   pois dia, m�s e ano ainda n�o foram informados: */
	Imprime( &dtHoje ); 
	
	/* altera para valores corretos: */
	Altera( &dtHoje, 1, 12, 2001 );
	Imprime( &dtHoje ); /* e imprimir� normalmente */

	/* altera para valores incorretos: */
	Altera( &dtHoje, 1, 13, 2001 );
	Imprime( &dtHoje ); /* e imprimir� mensagem de erro */

	/* para a vari�vel "dtPagamento" n�o foi usada a fun��o "Inicia"
	   e tamb�m n�o foi usada a fun��o "Altera" antes de imprimir:
	*/
	dtPagamento.m_cDia = 55; /* sem valida��o... */

	/* agora ir� imprimir um dia incorreto
	   e, para m�s e ano, apenas lixo: */
	Imprime( &dtPagamento );

	return 0;
}

/*
 RESULTADO:

??:??:????		-	mensagem de erro
01/12/2001		-	imprimiu normalmente dados corretos
??:??:????		-	mensagem de erro
55/-52/-13108 	-	nesta linha o resultado, para m�s e ano, 
					� indeterminado, pois, na verdade,
					est� imprimindo LIXO.
*/
