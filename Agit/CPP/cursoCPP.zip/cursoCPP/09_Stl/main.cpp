#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
int main()
{
    std::string nome("Maria");
    std::cout << nome << "\n";
    nome += " Aparecida";
    std::cout << nome << "\n";
    std::string nome2 = nome.substr(6);
    std::cout << "nome 2 = "  << nome2 << "\n";
    nome2 = nome.substr(6, 7);
    std::cout << "nome 2 = "  << nome2 << "\n";

    std::vector < int > vi;
    vi.reserve( 50 );// uma reserva evita realoca��es desnecess�rias
    std::cout << "tamanho reservado: " << vi.capacity() <<"\n";
    std::cout << "elementos alocados: " << vi.size() << "\n";
    vi.push_back ( 10 );
    vi.push_back( 5 );
    vi.push_back(1);
    size_t i ;
    std::cout << "percorrendo 'vi'\n";
    for ( i =0 ; i < vi.size(); ++i)
        std::cout << vi[i] << "\n";
    std::cout << "\n";

    std::sort(vi.begin(), vi.end());
    std::cout << "percorrendo 'vi' apos sort\n";
    for ( i =0 ; i < vi.size(); ++i)
        std::cout << vi[i] << "\n";
    std::cout << "\n";

    std::cout << "<enter> p/sair\n";
    std::cin.get();
    return 0;
}
