#include <iostream>
#include <ctime>     // fun��es para tempo
#include <cstdlib>
using namespace std;

class Timer
{
        public:
                Timer() // construtora
                {
                }
                ~Timer() // destrutora
                {
                }

                // fun��o virtual: ser� melhor especificada em uma derivada:
                virtual bool TempoDecorrido(int nVezes)
                {
                        cout << "BASE: passou aqui inutilmente" << endl;
                        // mas essa fun��o n�o faz nada...
                        // ser� que poderia ser eliminada?
                        return false;
                }

                void Executa( int nIntervalo ) // segundos
                {
                        int nVezes = 0;
                        bool bOK;
                        do
                        {
                                Pausa( nIntervalo );
                                ++nVezes;
                                bOK = TempoDecorrido(nVezes);

                        } while ( bOK );
                }
                void Pausa(int nIntervalo)
                {
                        clock_t Inicio = clock();
                        clock_t Fim = Inicio + (nIntervalo*CLOCKS_PER_SEC);
                        while ( Inicio < Fim )
                        {
                                Inicio = clock();
                        }
                }
};

class Despertar : public Timer // derivada de "Timer"
{
public:
        // redefine a VIRTUAL da base:
        bool TempoDecorrido(int nVezes)
        {
                if (nVezes > 5 )
                        return false; // interrompe o Timer
                cout << "DERIVADA: acordei ... trabalhando... " << nVezes << endl;
                return true;
        }

        Despertar()
        {
        }

        ~Despertar()
        {
        }
} ;
int main()
{
        Timer t1; // objeto da classe base
        t1.Executa( 1 ); // 1 segundo
        // o objeto da classe base n�o far� nada de �til...

        cout << endl;

        // agora sim temos algo:
        Despertar desp; // derivada...
        desp.Executa( 1 ) ;

        cout << "\n<enter> p/sair\n";
        std::cin.get();

        return 0;
}



