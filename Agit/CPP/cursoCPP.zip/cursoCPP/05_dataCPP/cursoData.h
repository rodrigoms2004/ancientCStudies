#ifndef CURSODATA_H
#define CURSODATA_H
// struct cursoData
// mas � melhor (para encapsulamento) usar "class"
// onde o acesso default � "private"
class cursoData
{
    private:   // membros de dados e eventualmente
                    // fun��es internas, auxiliares
        int m_dia, m_mes, m_ano;
        int m_anoMin, m_anoMax ;
        bool m_ok;
public:
        static const int m_anoMinDefault = 0;
        static const int m_anoMaxDefault = 9999;
        int m_lixo ;
        // poderia ter feito:
       //  enum { anoMinDefault = 0, anoMaxDefault = 9999 } ;

    public:  // fun��es membras que podem ser usadas
                // em qualquer lugar
        // fun��es que tenham o mesmo nome da 'struct'
        // s�o CONSTRUTORAS (chamadas automaticamente
        // quando uma vari�vel desse tipo � criada)
        cursoData(/* cursoData * this , */) ; // ao inv�s de"inicia"...
        cursoData(/* cursoData * this , */
                    int dia, int mes, int ano ) ; // ao inv�s de"inicia"...

        bool Altera (/* cursoData * this , */
                                                   int dia, int mes, int ano) ;
        void Imprime ( /* const cursoData * this */ ) const ;

        // fun��es implementadas DENTRO da class/struct
        // s�o "inline" por default:
        /* inline */ int getDia() const {
                         exception_on_error_();
                         return m_dia ;
                     }
        int getMes() const { exception_on_error_();
            return m_mes ; }
        int getAno() const { exception_on_error_();
            return m_ano ; }

        // inline declarada explicitamente:
        inline bool AnoBissexto() const ;
private:
        inline  int  UltimoDiaMes_() const ;
public:
        inline  int  UltimoDiaMes() const ;

        // obedece ao ESCOPO da class e �s regras
        // "public / private":
        enum { Janeiro=1, Fevereiro, Marco, Abril, Maio, Junho,
                   Julho, Agosto, Setembro, Outubro, Novembro,
                   Dezembro };

        // #define: sempre no escopo GLOBAL(EVITE SEMPRE):
        #define JANEIRO  1
int Compara( /* const cursoData * this , */
                                        const cursoData & other) const;

bool operator<(const cursoData&other)const
                                { return this->Compara(other ) < 0 ; }
 bool operator>(const cursoData&other)const
                               { return Compara(other ) > 0 ; }
bool operator>= (const cursoData&other)const
                                { return Compara(other ) >= 0 ; }
bool operator<=(const cursoData&other)const
                                { return Compara(other ) <= 0 ; }
bool operator==(const cursoData&other)const
                                { return Compara(other ) == 0 ; }
bool operator!=(const cursoData&other)const
                                { return Compara(other ) != 0 ; }
// cursoData pag;
// cursoData venc;
// if ( pag > venc )
    // "pag" � recebido como "this"
    // e "venc" � recebido como "other"

private:
        inline void exception_on_error_() const
        {
            if ( !m_ok )
                throw "data incorreta" ; // interrompe o programa
        }
} ;  // FIM da declara��o da class "cursoData"
// Fun��es inline implementadas FORA da class/struct
// devem ser escritas AQUI, ou em arquivo aqui inclu�do:
// #include "cursoData.inl"
inline bool cursoData::AnoBissexto() const
{
        if ( (m_ano & 3) !=0 ) // se resto da divis�o por 4 n�o � ZERO
            return false; // n�o �  bissexto

        // se chegou aqui divide por 4 (resto foi zero)
        // n�o pode ser div�sivel por 100,
        // exceto se for div�sivel por 400
        return (m_ano % 100!=0) || (m_ano % 400 == 0);
}
// private:
inline  int  cursoData::UltimoDiaMes_() const
{
    if ( m_mes == Fevereiro)
        return 28+AnoBissexto();

    return m_mes <= Julho ?  30 + (m_mes & 1)
                                      :  31- (m_mes & 1);
}
// public:
inline  int  cursoData::UltimoDiaMes() const
{
    exception_on_error_();

    // chama a fun��o private:
    return UltimoDiaMes_();
}

/* uso:
    cursoData pagamento;  // construtora � chamada AQUI
    cursoData vencimento; // IDEM
    // se os dados fossem "public" eu poderia:
    // pagamento.m_dia = 10; //mas, � private(erro de compila��o)

    pagamento.Altera(1,1,2010);
    vencimento.Altera(2,1,2010);

    // c�digo que ser� gerado (usando 'pagamento' como exemplo)
    cursoData pagamento;
    1) aloca 'pagamento' na mem�ria
    2) push &pagamento     // empurra para a pilha o endere�o
                       // de 'pagamento' que ser� recebido pela
                        // pr�xima chamada de fun��o no par�metro
                    // impl�cito (oculto) denominado 'this'
    3) call cursoData@cursoData@@N   // chama a construtora

    pagamento.Altera(1,12,2010);
    1) push 2010     // vai para a pilha como argumento
    2) push 12        // idem
    3) push 1          // idem
    4) push &pagamento  // idem (ser� recebido como  'this')
    5) call Altera@cursoData@@III
    // Observar que isso � o mesmo que faz�amos em C:
    // Altera( &pagamento, 1,12,2010);

    // obs: os nomes das fun��es em c�digo de m�quina
    // foram representados aqui CONCEITUALMENTE,
    // pois isso varia conforme o compilador.
*/

#endif // CURSODATA_H
