#include <iostream>
#include <iomanip> // manipuladores de IO, como "setw", etc..

#include "cursoData.h"

// fun��es que tenham o mesmo nome da 'struct'
// s�o CONSTRUTORAS (chamadas automaticamente
// quando uma vari�vel desse tipo � criada)
cursoData::cursoData(/* cursoData * this , */)  // ao inv�s de"inicia"...
    // aqui � feita a INICIALIZA��O
    : m_anoMin(m_anoMinDefault )
    , m_anoMax(m_anoMaxDefault )
    , m_ok ( false )
{
    // aqui: atribui��es e outras opera��es
    /*
    this->m_ok = false ; // ok
    // MAS o "this" � assumido aqui  por default
    // logo n�o � necessario explicit�-lo:
    m_ok = false;  // ok tamb�m
    */
}
cursoData::cursoData(/* cursoData * this , */
            int dia, int mes, int ano )  // ao inv�s de"inicia"...
       : m_anoMin(m_anoMinDefault )
       , m_anoMax(m_anoMaxDefault )
{

    // this->Altera(dia, mes, ano);
    // o 'this' � assumido por default... ENT�O, posso:
    Altera(dia, mes, ano);
}
bool cursoData::Altera (/* cursoData * this , */
                                             int dia, int mes, int ano)
{
    m_dia = dia ; m_mes = mes ; m_ano = ano ;
    m_ok = m_ano >= m_anoMin && m_ano <= m_anoMax &&
                m_mes >= 1 && m_mes <= 12 &&
                m_dia >=1  && m_dia <= UltimoDiaMes_() ;

    return m_ok ;
}
void cursoData::Imprime ( /* const cursoData * this */ ) const
{
    if ( m_ok )
    {
        // imprime a data
        std::cout.fill('0'); // caracter de preenchimento � esquerda
        std::cout   << std::setw(2) << m_dia << '/'
                << std::setw(2)   << m_mes << '/'
                << std::setw(4) << m_ano << '\n';
    }
    else  // mensagem de erro
        std::cout << "***ERRO***\n" ;
    std::cout << std::endl;

}
int cursoData::Compara( /* const cursoData * this , */
                                        const cursoData & other) const
{
    if ( this->m_ano != other.m_ano)
        return this->m_ano - other.m_ano ;

    return ( this->m_mes != other.m_mes )
                    ? this->m_mes - other.m_mes
                    : this->m_dia - other.m_dia ;
    // e o retorno ser�:
    // menor que zero se a primeira estiver menor
    // maior que zero se a primeira estiver maior
    // zero, se estiverem iguais.
}


