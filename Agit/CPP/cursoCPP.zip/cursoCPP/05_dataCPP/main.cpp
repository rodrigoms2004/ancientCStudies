#include <iostream>
#include "cursoData.h"
int main()
{
    std::cout << "imprimindo uma est�tica da classe : "
                    << cursoData::m_anoMaxDefault << "\n";


    // ERRO: m_lixo n�o � est�tica:
   // std::cout << "imprimindo um membro p�blico da classe : "
      //              << cursoData::m_lixo << "\n";

    // precisa ser alocada na mem�ria como MEMBRO (campo)
    // de uma vari�vel (objeto) "cursoData":
    cursoData dtTeste ;
    std::cout << "imprimindo um membro p�blico da classe : "
                    << dtTeste.m_lixo << "\n";



    std::cout << "JANEIRO(define)" << JANEIRO << "\n";

    // error: 'Janeiro' was not declared in this scope
    //std::cout << "Janeiro(enum)"  << Janeiro << "\n";
    // corre��o: usar o escopo correto da constante "Janeiro":
    std::cout << "Janeiro(enum)"
                                              << cursoData::Janeiro << "\n";

    cursoData pagamento ;

    // error: 'int cursoData::m_dia' is private
    // pagamento.m_dia = 55; // PRIVATE: n�o posso acessar
    // esse membro fora das fun��es da classe ou de suas amigas

    pagamento.Altera(12, 13, 2001);
    pagamento.Imprime();

    try
    {
         std::cout << "dia do pagamento " << pagamento.getDia()
                                                                            <<"\n";
     }
    catch (const char * err) // bloco caso ocorra uma exception
    {
        std::cout << "Algo errado. Mensagem: " << err << "\n";
    }

    pagamento.Altera(13, 12, 2001);
    pagamento.Imprime();

    cursoData vencimento ( 10, 11, 2002);
    vencimento.Imprime();

    std::cout << "testa dia 31, todos os meses\n";
    int mes ;
    for ( mes = cursoData::Janeiro;
                                            mes<=cursoData::Dezembro ;
                                                                         ++mes)
    {
        cursoData dt(31, mes, 2010); // testa dia 31
        dt.Imprime();
    }
    std::cout << "testa dia 29, para fevereiro\n";
    cursoData testaFev;
    testaFev.Altera( 29, 2, 1997);
    std::cout << "ano 1997 = "; testaFev.Imprime();
    testaFev.Altera( 29, 2, 1900);
    std::cout << "ano 1900 = "; testaFev.Imprime();
    testaFev.Altera( 29, 2, 1996);
    std::cout << "ano 1996 = "; testaFev.Imprime();
    testaFev.Altera( 29, 2, 2000);
    std::cout << "ano 2000 = "; testaFev.Imprime();

    pagamento.Altera( 10, 2, 2010);
    vencimento.Altera( 9, 2, 2010);
    std::cout << "pagamento: " ; pagamento.Imprime();
    std::cout << "vencimento: " ; vencimento.Imprime();
    if ( pagamento.Compara( vencimento ) > 0)
        std::cout << "cobrar juros\n";
    else
        std::cout << "NAO cobrar juros\n";

    if ( pagamento > vencimento )
        std::cout << " 'operador >' - cobrar juros\n";
    else
        std::cout << " 'operador >' - NAO cobrar juros\n";

    // podemos escrever assim:
    if ( pagamento.operator >(vencimento))
        std::cout << " 'operador >' - cobrar juros\n";
        // N�O USE ASSIM...

    std::cout << "tecle <enter> para encerrar" << std::endl;
    std::cin.get(); // espera por um caracter <enter>
    return 0;
}

