#ifndef TABHIST_H
#define TABHIST_H

#include "TabRef.h"

class TabHist : public TabRef
{
public:
    TabHist()
            // : TabRef()     // inicializa��o default...
            // ,  m_obs()
    {
        CodMinMax();
    }
    TabHist(unsigned int cod, const std::string & descr,
                                             const std::string & obs = "")
          : TabRef(cod, descr)  // inicializa��o expl�cita
          , m_obs(obs)
    {
        CodMinMax();
    }
    void CodMinMax()
    {
        m_codMin =  101; // acessa membro protected da base
        m_codMax = 999; // idem;
    }
    // Redefinindo a fun��o "Imprimir" da classe base:
    void Imprimir(bool endLine = true)
    {
        TabRef::Imprimir(false); // neste caso, at� d� para
                                                    // aproveitar o que a base faz
        // e agora acrescentar:
        std::cout <<  " - " << m_obs ;
        if ( endLine )
            std::cout << "\n";
    }

    std::string m_obs;
    // membro de dados p�blico ???
    // Raz�es para SIM:
    // 1) m_obs pode ou n�o ser preenchido e com qualquer string
    // 2) quanto � aloca��o de mem�ria, std::string j� faz
            // a aloca��o/desaloca��o de forma segura.

    // Raz�es para N�O:
    // O tamanho m�ximo de uma string em std::string � IMENSO.
    // sera que n�o seria o caso de limitar esse tamanho?
};

#endif // TABHIST_H
