#ifndef TABREF_H
#define TABREF_H

#include <iostream>
#include<string>

class TabRef
{
private:
    unsigned int m_cod;
    std::string m_descr;

protected:
    static const unsigned int m_codErr = 0;
    // na base teremos valores default no intervalo
    // o mais amplo poss�vel
    static const unsigned int m_codMinDeft = 1;
    static const unsigned int m_codMaxDeft = 0xFFFFFFFF;

    // estes valores ser�o melhor resolvidos em derivadas:
    // por isso "protected"):
    unsigned int m_codMin;
    unsigned int m_codMax;

public:
    TabRef()
        : m_cod(m_codErr)
        // , m_descr() // por default, chama a construtora default
                              // de std::string
        , m_codMin(m_codMinDeft )
        , m_codMax(m_codMaxDeft )
    {}

    TabRef(unsigned int cod, const std::string & descr)
        : m_cod( cod)
        , m_descr(descr)  // ganho de PERFORMANCE: chamo
                // a construtora de std::string que recebe argumento
        , m_codMin(m_codMinDeft )
        , m_codMax(m_codMaxDeft )
    {
        // se eu, ao inv�s da inicializa��o fizesse a atribui��o aqui:
        // m_descr = descr ;
        // Na inicializa��o ter�amos perdido a viagem, pois teria
        // sido chamada a construtora default, para agora
        // fazer a atribui��o...
        ValidaCod_();
        ValidaDescr_();
    }


    unsigned int Codigo() const   // get
    {
        if ( m_cod == m_codErr ) throw "objeto inv�lido";
        return m_cod;
    }
    void Codigo (unsigned int cod)  // set
    {
        m_cod = cod;
        ValidaCod_();
    }
    const std::string & Descricao()const
    {
        if ( m_cod == m_codErr ) throw "objeto inv�lido";
        return m_descr;
    }
    void Descricao(const std::string & descr)
    {
        m_descr = descr;
        ValidaDescr_();
    }
    void Imprimir( bool endLine = true)
    {
        if ( m_cod == m_codErr)
            std::cout << "objeto invalido";
        else
            std::cout << m_cod << " - " << m_descr;

        if ( endLine)
            std::cout << "\n";
    }

private:
    void ValidaCod_()
    {
        if(m_cod<m_codMin || m_cod>m_codMax)
            m_cod = m_codErr;
    }
    void ValidaDescr_()
    {
        // para fazer: parametrizar tamanho m�nimo e m�ximo
        // da descri��o (do mesmo modo que foi feito para m_cod):
        if(m_descr.length()<2 || m_descr.length()>1024)
            m_cod = m_codErr;
    }
};

#endif // TABREF_H
