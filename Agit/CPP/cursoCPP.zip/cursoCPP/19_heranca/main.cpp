#include "tabref.h"
#include "tabhist.h"

int main()
{
    TabRef tr1; // construtora default;
    tr1.Imprimir();
    tr1.Codigo(10);
    tr1.Descricao("produto 10");
    tr1.Imprimir();
    TabRef tr2(11, "produto 11"); // construtora c/argumentos
    tr2.Imprimir();

    TabHist th1 ;
    th1.Codigo(101); // TabHist herdou essa fun��o;
    th1.Descricao("Historico 101") ; // idem
    th1.m_obs = "Obs 101";
    th1.Imprimir();

    TabHist th2(102, "Historico 102");
    th2.m_obs = "Obs 102";
    th2.Imprimir();

    // acima, perdemos tempo, pois poder�amos ter feito isto:
    TabHist th3(103, "Historico 103", "Obs 103");
    th3.Imprimir();

    std::cout <<  "<enter> p/sair\n";
    std::cin.get();

    return 0;
}
