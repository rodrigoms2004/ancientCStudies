#include <iostream>
#include <string>
#include <exception>
#include <cstdlib>

// emite uma mensagem final
void MsgFinal()
{
	std::cout << "\n<enter> p/sair\n";
	std::cin.get();
}

	// tipo parametrizado     valor constante
	//                        \|/           \|/
template <typename T, size_t Dim> class VetorFixo
{
	private:
		T m_Vetor[ Dim ]; // vetor de "T" com dimens�es fixas

		// Classe aninhada para tratamento de exce��es
		// (aninhada, pois s� serve para trabalhar com "VetorFixo").
		// As fun��es "get" e "set" de VetorFixo<> usar�o esta classe
		// para disparar exce��es:
		class Exception : public std::exception // deriva da classe padr�o da STL
		{
			friend class VetorFixo<T, Dim> ;
			// a��es que podem provocar uma exce��o (fun��es get/set de "VetorFixo"):
			enum Action { Nulo, actGet, actSet } ;
			Action m_action ;

			// construtora private (poder� ser usada apenas na sua "friend" VetorFixo<>):
			Exception( Action action ) : m_action ( action ) {}

			public:
			// redefine virtual DA BASE:
			virtual const char* what() const throw()  // o "throw()" aqui - sem especificac�o de tipo - adverte que esta fun��o n�o dispara exceptions
			{
				switch ( m_action )
				{
					case actGet : return "VetorFixo::GET : indice incorreto" ;
					case actSet : return "VetorFixo::SET : indice incorreto" ;
					default:
						return std::exception::what(); // algo inesperado aqui ...
				}
			}
		} ;

		// fun��es est�ticas que redefinem os tratadores "default" para exceptions:
		// se ocorrer um "throw" e ele n�o for capturado em um "try/catch",
		// os tratadores ser�o estes:
		static void excecaoDefault_getFunc ()
		{
			std::cout << "\nTERMINATE: VetorFixo::GET: indice incorreto : sem try/catch)\n" ;
			MsgFinal();
			exit(-1); // encerra aplica��o
		}
		static void excecaoDefault_setFunc ()
		{
			std::cout << "\nTERMINATE: VetorFixo::SET: indice incorreto :  (sem try/catch)\n" ;
			MsgFinal();
			exit(-1); // encerra aplica��o
		}

	public:
		VetorFixo(){}

		inline size_t Size () { return Dim ; }


		// verificam �ndice:
		inline const T & Get(  size_t nIndice )
		{
			{
				if ( nIndice >= Dim )
				{
					// redefine o tratador default (caso a exce��o n�o seja capturada em um try/catch)
					std::set_terminate( excecaoDefault_getFunc );
					Exception err ( Exception::actGet );
					throw err;
				}
				return m_Vetor [ nIndice ];
			}
		}
		inline void Set(  size_t nIndice,  const T & newValue )
		{
			if ( nIndice >= Dim )
			{
				// redefine o tratador default (caso a exce��o n�o seja capturada em um try/catch)
				std::set_terminate( excecaoDefault_setFunc );
				Exception err ( Exception::actSet );
				throw err;
			}
			m_Vetor [ nIndice ] = newValue;
		}


		// n�o verificam �ndice:
		inline T & operator[ ] ( size_t nIndice )
		{
			return m_Vetor[ nIndice] ;
		}
		inline const T & operator[ ] ( size_t nIndice ) const
		{
			return m_Vetor[ nIndice] ;
		}
};

void TrataExcecaoDefault ()
{
	std::cout << "impossivel continuar" << std::endl;
	exit(-1); // encerra aplica��o
}

int main()
{
	// esse "set_terminate" aqui � gen�rico demais...
	// nunca saberemos onde ocorreu o problema.
	std::set_terminate( TrataExcecaoDefault );

	const int viDim  = 5 ;
	VetorFixo< int , viDim > vi;

	vi.Set ( 2, 1); // OK: acessa elemento alocado

	try  // provoca exception com a fun��o "Get":
	{
		std::cout << vi.Get( viDim )  << "\n"; // acessa elemento n�o alocado...
	}
	catch(  std::exception & err )
	{
		std::cout << "Erro: " << err.what() << "\n";
	}
	catch(...)   // se o tipo do erro n�o for "std::exception" ent�o vai cair aqui
	{
		std::cout << "algo desconhecido, talvez terrivel, ocorreu\n";
	}

	try  // provoca exception com a fun��o "Set":
	{
		vi.Set( viDim, 10 ) ; // acessa elemento n�o alocado...
	}
	catch(  std::exception & err )
	{
		std::cout << "Erro: " << err.what() << "\n";
	}

	// Acessa elemento n�o alocado sem "try/catch".
	// O "terminate" sera usado:
	int x = vi.Get( viDim ) ;
	std::cout << x << "\n";

	MsgFinal();
	return 0;
}
