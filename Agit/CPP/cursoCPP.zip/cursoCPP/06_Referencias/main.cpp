#include <iostream>
using namespace std;
// "rparam" � uma refer�ncia e N�O um ponteiro
// (um ponteiro seria "int * rparam")
void func( int & rparam )
{
        cout << "conteudo REFERENCIADO por 'rparam' = "
                                                        <<  rparam << endl;
        cout << "endereco de 'rparam' = " << &rparam << endl;

        // EM REFER�NCIAS ISTO ESTARIA ERRADO:
//        cout << "conteudo APONTADO por 'rparam' = " << *pparam << endl;
//        *pparam = 10; // alterando a mem�ria APONTADA

  // DEVE SER USADO ASSIM(como foi feito na primeira linha)
  //      cout << "conteudo REFERENCIADO por 'rparam' = "
     //                                                   << rparam << endl;
        rparam = 10; // alterando a mem�ria REFERENCIADA
}
int main()
{
        int x = 5; // "x" � o apelido de um endere�o de mem�ria
                                        // onde armazenei o N�MERO INTEIRO 5;

        int * p = &x; // "px" � o apelido de um OUTRO endere�o de mem�ria

        int & r = x; // "r" N�O � uma NOVA mem�ria
                            // "r" � um SIN�NIMO para "x"
                            // o "=" ai N�O � uma atribui��o
                            // � uma ASSOCIA��O.

        // onde armazenei o ENDERE�O de "x"
        cout << "conteudo de 'x' = " <<  x << endl;
        cout << "endereco de 'x' = " << &x << endl;
        cout << "conteudo de 'r' = " <<  r << endl;
        cout << "endereco de 'r' = " << &r << endl;
        cout << "conteudo de 'p' = " <<  p << endl;
        cout << "endereco de 'p' = " << &p << endl;
        cout << "conteudo APONTADO por 'p' = " << *p << endl;

        func(x); // o par�metro de "func" � uma refer�ncia para
                        // um "int"; logo esse par�metro sera
                        // um "sin�nimo" para "x" e n�o uma
                        // nova mem�ria.

        cout << "conteudo de 'x' apos 'func' = " << x << endl;

        std::cout << "tecle <enter> para encerrar" << std::endl;
        std::cin.get(); // espera por um caracter <enter>
        return 0;
}
/*  RESULTADO:
        conteudo de 'x' = 5
        endereco de 'x' = 0x22ff58
        conteudo de 'r' = 5
        endereco de 'r' = 0x22ff58
        conteudo de 'p' = 0x22ff58
        endereco de 'p' = 0x22ff54
        conteudo APONTADO por 'p' = 5
        conteudo REFERENCIADO por 'rparam' = 5
        endereco de 'rparam' = 0x22ff58
        conteudo de 'x' apos 'func' = 10

          \|/------------------------------\
        |   5 , 10    |                    |   22ff58   |
        --------------                    --------------
  'x', 'r', 'rparam' (22ff58)            'p'(12FF54)
*/
