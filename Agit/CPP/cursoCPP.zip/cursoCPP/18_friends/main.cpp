#include <iostream>
class dbConnection
{
    // aqui j� virou um "facebook":
    // friend int main();

    friend class dbCommand ;

private:
    int m_connHandle;
public :
        dbConnection(int connHandle)
            : m_connHandle(connHandle)  // inicializa��o
            // , m_connHandle(outra_coisa) // ERRO: dupla inicializa��o
    {
        // atribui��o
          //   m_connHandle = connHandle ;
     //m_connHandle = outra_coisa ; // OK: pode ter v�rias atribui��es
    }
};
class dbCommand
{
   dbConnection * m_dbConn;
public:
   dbCommand (dbConnection * dbConn)
       : m_dbConn( dbConn )
   {}
   void Exec(const std::string & cmdText)
   {
       std::cout << "executando: " << cmdText
               << " na conexao: " << m_dbConn->m_connHandle
               << "\n";   // como foi declarada "friend" por dbConnection
                // est� acessando o seu membro private "m_connHandle"
   }
};
int main()
{
    dbConnection db1(1);
    dbCommand dbCmd_1a ( &db1 );
    dbCommand dbCmd_1b ( &db1 );

    dbConnection db2(2);
    dbCommand dbCmd_2a ( &db2 );
    dbCommand dbCmd_2b ( &db2 );

    dbCmd_1a.Exec("SELECT * FROM Clientes");
    dbCmd_1b.Exec("SELECT * FROM Pessoas");

    dbCmd_2a.Exec("INSERT -> CLIENTES");
    dbCmd_2b.Exec("INSERT -> PESSOAS");
    return 0;
}
