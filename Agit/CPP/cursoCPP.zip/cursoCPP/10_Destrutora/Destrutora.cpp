#include <iostream>
#include <vector>
using namespace std;

// obs: apenas para demonstrar a utilidade de destrutoras
// pois j� existe um template assim na biblioteca padr�o:
// o vector ...
template < class T > class VetorHeap 
{
	T * m_Vetor;
	unsigned int m_nSize;
	unsigned int m_nJaAlocado;
	bool m_bError;
        static const unsigned int m_preservaMemJaAlocadaMax
                                                                        = 2048;
 
public:
	VetorHeap() // construtora
	{
		m_bError = false;
		m_nSize=0;
		m_nJaAlocado=0;
                m_Vetor = 0;
	}
        ~VetorHeap() //<<<<<<<DESTRUTORA
        {
                LiberaMemoria();
        }
	void LiberaMemoria()
	{
                if ( m_Vetor != 0 )
		{
			delete [] m_Vetor;
			m_Vetor=NULL;
		}
	}
	void Resize(unsigned int NewSize)
	{
                if ( NewSize > m_nJaAlocado
              || m_nJaAlocado-NewSize > m_preservaMemJaAlocadaMax )
		{
			T * pTemp = new T [ NewSize ] ;
			unsigned int nC ;
			for ( nC =0; nC < m_nSize; nC++ ) // salva...
				pTemp[ nC ] = m_Vetor[nC] ; 
			
			LiberaMemoria();
			m_Vetor = pTemp;
			m_nJaAlocado = NewSize;
		}
		m_nSize = NewSize;
	}

        // "Valor" est� sendo passado por refer�ncia
        // pois "T" tanto pode ser um simples int
        // como pode ser uma estrutura muito grande
	void Set( unsigned int Indice, const T & Valor )
	{
		m_bError = ( Indice >= m_nSize ) ;

		if ( !m_bError )
			m_Vetor [ Indice ] = Valor;
	}

        // valRet � um par�metro de sa�da
        bool  Get ( unsigned int Indice, T & valRet )
	{
		m_bError = ( Indice >= m_nSize ) ;
                if ( !m_bError )
                {
                    valRet = m_Vetor[ Indice ] ;
                    return true;
                }
                return false;
	}

        // sem verifica��o:
        T & operator[]( unsigned int index)
        {
            return m_Vetor[ index ];
        }

	unsigned int Size() const { return m_nSize; }
	bool GetError() const { return m_bError; }
};

int main()
{
	VetorHeap< int > vhi;
	unsigned int nC;
	
	vhi.Resize( 5 );
	for ( nC=0; nC < vhi.Size(); nC++ )
                vhi[nC] = nC + 1;

	cout << "com 5 elementos" << endl;

        for ( nC=0; nC < vhi.Size(); nC++ )
            cout << vhi[nC] << " - ";

        cout << endl;

	unsigned int OldSize = vhi.Size();
	vhi.Resize( 8 );
	
	for ( nC = OldSize ; nC < vhi.Size(); nC++ )
                vhi[ nC ] = (nC+1)*10 ;

	cout << "\ncom 8 elementos (os 5 iniciais nao foram alterados)" << endl;	
	for ( nC=0; nC < vhi.Size(); nC++ )
                cout << vhi[nC] << " - " ;

	cout << endl << endl;
	
        cout <<  "tecle <enter> p/sair\n";
   //     cin.get();
	return 0;
}

