#include <iostream>
class Base
{
	protected:
		virtual void DoNothing() {
			std::cout << "Base::DoNothing" << std::endl;
		}
	public:
		int x;
		void ExecDoNothing() { DoNothing() ; }
};
class Deriv : public Base
{
	public:
		int y;
		void DoNothing() {
			std::cout << "Deriv::DoNothing" << std::endl;
		}
};

int TestaCastPersonalizado();

int main()
{
	// a) um cast INSUSPEITO;
	int a = 5;
	double d = double ( a ) / 2;  // int para double: ok;
	// b) um cast SUSPEITO:
	a = int  ( d ); // ser� que n�o vai truncar a pr�pria parte inteira???
	// ent�o documente melhor:
	a = static_cast<int>( d );
	// c) um cast MUITO SUSPEITO:
	int * p = (int*)100; // bem, isso pode ser necess�rio
									// em certas plataformas.
	// ent�o documente melhor (tipos n�o relacionados):
	p = reinterpret_cast<int *>(100);
	// d) um cast MUITO MUITO SUSPEITO:
	char ch;
	const char * pch1 = &ch;
	char * pch2 = (char *) pch1;
	// const para n�o-const ??????
	// ent�o:
	pch2 = const_cast<char*>( pch1);

	// e) convers�es classe-base/classe-derivada:
	// static_cast  - a convers�o � documental; sem verifica��o
	// ou dynamic_cast : verificado em tempo de execu��o
	// depende de suporte a RTTI (Run Time Type Implementation);
	// seu uso pode comprometer a performance.

	Base * pBase1  = new Base;
	Deriv * pDeriv1 = new Deriv;
	Base * pBase2 ;
	Deriv * pDeriv2;

	pBase2 = static_cast <Base*>(pDeriv1);
	pBase2->ExecDoNothing();
	pBase2 = dynamic_cast <Base*>(pDeriv1);
	pBase2->x = 5;
//	pBase2->y = 5 // erro de compila��o; embora o objeto seja "Deriv"
						// o ponteiro � "Base" que n�o tem "y"
	if ( pBase2 == 0 )
		std::cout << "cast incorreto" << std::endl;
	else
		std::cout << "cast correto" << std::endl;

	// isto (convers�o de Base para Derivada)
	// nunca deveria ser feito; no m�nimo � c�digo confuso
	// e, no pior caso, pode levar a acessos esp�rios � mem�ria.
	pDeriv2 = static_cast <Deriv*>(pBase1);
	pDeriv2->ExecDoNothing();
	pDeriv2->x = 5; // ok;
//>>	pDeriv2->y = 10; // "y" N�O EST� ALOCADO NA MEM�RIA.
//	std::cout << pDeriv2->y << std::endl;

	pDeriv2 = dynamic_cast <Deriv*>(pBase1);
	if ( pDeriv2 == 0)
		std::cout << "cast incorreto" << std::endl;
	else
	{   // n�o vai passar por aqui...
		std::cout << "cast correto" << std::endl;
		pDeriv2->ExecDoNothing();
		pDeriv2->x = 5;
		pDeriv2->y = 10; // !!!!!
	}

	TestaCastPersonalizado();

	std::cout << "\n<enter> p/sair\n";
	std::cin.get();
	return 0;
}
// casts criados pelo programador
template <typename T_TARGET, typename T_SOURCE> T_TARGET my_cast(T_SOURCE & value)
{
	std::cout << "static"  << std::endl;
	return static_cast<T_TARGET>(value);
}

int TestaCastPersonalizado()
{
	std::cout << "\n\n==== Casts Personalizados\n";
	int p = 65;
	std::cout << p << std::endl;

	char x1 = my_cast<char>(p);
	std::cout << x1 << std::endl;

	return 0;
}

