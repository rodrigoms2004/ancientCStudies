#include <iostream>
using namespace std;
void func( int * pparam )
{
	cout << "conteudo de 'pparam' = " <<  pparam << endl;
	cout << "endereco de 'pparam' = " << &pparam << endl;
	cout << "conteudo APONTADO por 'pparam' = " << *pparam << endl;
	*pparam = 10; // alterando a mem�ria APONTADA
	
	// error C2440: '=' : cannot convert from 'int' to 'int *'		
//	pparam = 10 ; // estou considerando '10' como um endere�o !!
						 // pois estou gravando '10' no ponteiro!!
  
//	pparam = (int*) 10; // assumi EXPLICITAMENTE que '10' � um endere�o
	// e vou escrever nesse endere�o:
//	*pparam = 100; //  BOMBA (mas h� plataformas em que coisas assim
							// s�o a �nica alternativa...)
}
int main()
{
	int x = 5; // "x" � o apelido de um endere�o de mem�ria
					// onde armazenei o N�MERO INTEIRO 5;

	int * p = &x; // "px" � o apelido de um OUTRO endere�o de mem�ria
						// onde armazenei o ENDERE�O de "x"
	cout << "conteudo de 'x' = " <<  x << endl;
	cout << "endereco de 'x' = " << &x << endl;
	cout << "conteudo de 'p' = " <<  p << endl;
	cout << "endereco de 'p' = " << &p << endl;
	cout << "conteudo APONTADO por 'p' = " << *p << endl;
	func(&x); // ou func (p); // j� que 'p' est� com o endere�o de 'x' 
	cout << "conteudo de 'x' apos 'func' = " << x << endl;
	return 0;
}
/*  RESULTADO:
conteudo de 'x' = 5
endereco de 'x' = 0012FF60
conteudo de 'p' = 0012FF60
endereco de 'p' = 0012FF54
conteudo APONTADO por 'p' = 5
conteudo de 'pparam' = 0012FF60
endereco de 'pparam' = 0012FE80
conteudo APONTADO por 'pparam' = 5
conteudo de 'x' apos 'func' = 10

          \|/---------------\               
	|   5 , 10    |    |   12FF60   |    |   12FF60   |
    --------------     --------------   --------------   
    'x' (12FF60)        'p'(12FF54)    'pparam'(12FE80)
*/