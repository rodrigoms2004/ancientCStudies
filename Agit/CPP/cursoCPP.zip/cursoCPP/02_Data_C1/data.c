/* arquivo data.c */

/* Em primeiro lugar, precisamos incluir os arquivos 
   onde est�o declarados:
	1)	a fun��o "printf", que ser� usada em "Imprime"
	2)	a estrutura "Data", 
		os prot�tipos para as fun��es especializadas em "Data" e
		os demais recursos (typedef e #define) usados pela estrutura
		ou pelas fun��es:
*/

#include <stdio.h>  /* para "printf" */
#include "data.h"   /* para a estrutura "Data"... */

/*	atribui valores "default" 
	para os campos de controle: 
*/
Data Inicia( Data dtParam ) 
{
	dtParam.m_shAnoMin  = ANO_MIN_DEF ;
	dtParam.m_shAnoMax = ANO_MAX_DEF ;

	dtParam.m_bOK = FALSE;  /* << esta vari�vel do tipo "Data" ainda n�o tem 
								  valores v�lidos para dia, m�s ou ano; 
								  ent�o deve ser assinalada como inv�lida 
							 */
	return dtParam;
}


/* alterar uma vari�vel do tipo Data: 
*/
Data Altera ( Data dtParam, char cDia, char cMes, short shAno )
{
	dtParam.m_cDia  = cDia ;
	dtParam.m_cMes  = cMes;
	dtParam.m_shAno = shAno;

	/* an�lise e valida��o dos valores recebidos
		(obs:	na vers�o em C++ faremos a an�lise correta 
				do �ltimo dia de cada m�s; 
				aqui ser� usado apenas "31" para todos os meses): 
	*/
	/*
	if (  dtParam.m_shAno >= dtParam.m_shAnoMin  &&    // and 
		   dtParam.m_shAno <= dtParam.m_shAnoMax && 
		   dtParam.m_cMes >= 1 && dtParam.m_cMes <= 12 && 
		   dtParam.m_cDia  >= 1 && dtParam.m_cDia <= 31 )
	{
		dtParam.m_bOK = TRUE;    // valores corretos 
	}
	else
	{
		dtParam.m_bOK = FALSE;    // valores incorretos 
	}
*/
	// melhor seria:
	dtParam.m_bOK = dtParam.m_shAno >= dtParam.m_shAnoMin && /*and */
		   dtParam.m_shAno <= dtParam.m_shAnoMax && 
		   dtParam.m_cMes >= 1 && dtParam.m_cMes <= 12 && 
		   dtParam.m_cDia  >= 1 && dtParam.m_cDia <= 31 ;
	return dtParam;
}

/* imprimir uma vari�vel do tipo Data: 
*/
void Imprime ( Data dtParam )
{
	if ( dtParam.m_bOK ) /* se a vari�vel estiver v�lida, imprime os campos: */
	{
		printf ( "%02d/%02d/%04d\n" ,
					dtParam.m_cDia  , 
					dtParam.m_cMes , 
					dtParam.m_shAno ) ;
	}
	else /* os dados est�o incorretos; ent�o imprime uma mensagem de erro: */
	{
		printf("??:??:????\n");
	}
}
