#include <memory>
#include <iostream>

/* alocando objetos no heap:
		int x = ....;
		int * p0 = new int ( 1 ) ;
		int * p1 = new int ;
		int * p2 = new int [ x ];  
            // new aloca no heap e CHAMA a CONSTRUTORA
		.......
		delete p1;
		delete [] p2;
        // delete CHAMA a DESTRUTORA e depois libera do heap

*/
// esta classe ("Qualquer") servir� para testar
// std::auto_ptr;
// objetos de "Qualquer" ser�o alocados no 'heap', 
// mas entregando o gerenciamento dos ponteiros para
// objetos "std::auto_ptr", os quais ir�o liberar os objetos "Qualquer"
// sempre que os objetos "auto_ptr" saiam de seu escopo.
// (evitando assim "memory leaks")
class Qualquer
{
		int m_x;

	public:
		Qualquer(int x=0) : m_x(x) {}

		// destrutora 
		// (apenas para demonstrar que ser� chamada
		// pela destrutora de "std::auto_ptr"):
		~Qualquer()
		{
			std::cout << "\n***** Qualquer::destrutora! (m_x = " 
						<<  m_x  << ")\n"  << std::endl;
		}
		void Set(int x) 
		{ 
			m_x = x; 
		}
		int Get() const { return m_x ; }
};

void test();
int main()
{
	test();
        std::cout << "<enter> p/sair\n";
        std::cin.get();
	return 0;
}
void test()
{
	std::auto_ptr<Qualquer> pq0 ( new Qualquer );
        std::cout << "'pq0->Get()' ==> "
                << pq0->Get() << std::endl;

	std::auto_ptr<Qualquer> pq1 ( new Qualquer(1) );
	std::cout << "'pq1->Get()' ==> " << pq1->Get() << std::endl;
	pq1->Set(10);
        std::cout << "'pq1->Get()' apos 'pq1->Set(10)' ==> "
                << pq1->Get() << std::endl;

	std::auto_ptr<int> pi( new int(2) );
	std::cout << "'*pi' ==> " << *pi << std::endl;
	*pi = 3;
	std::cout << "'*pi' apos '*pi=3' ==> " << *pi << std::endl;

} // destrutora de pi � chamada aqui e faz "delete ponteiro interno"

// destrutora de pq1 � chamada aqui chamando a destrutora Qualquer
						// via "delete ponteiro interno"

// destrutora de pq0 � chamada aqui chamando a destrutora Qualquer
						// via "delete ponteiro interno"

