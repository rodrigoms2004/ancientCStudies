#include <iostream>
double Fatorial( int num )
{
	double result;
	for ( result = 1; num>1; --num )
		result *= num;
	
	return result ;
}
double Fatorial_recurs( double num )
{
	if ( num <= 1 )
		return 1;

	return num * Fatorial_recurs( num - 1 );
}
double Potencia( int num, int exp )
{
	double result ;
	for (  result = 1; exp>0 ; --exp )
		result *= num;

	return result;
}
int main()
{
	std::cout << "testando funcoes" << std::endl;
	std::cout << "-Fatorial"  << std::endl;
	int n;
	for ( n = 0 ; n < 5; ++n)
		std::cout << "Fatorial de " << n << " = " <<Fatorial(n)
																				   <<std::endl;
	// AGORA, ESCREVA A FUN��O Potencia (parecida com Fatorial)
	// double Potencia(int base, int exp );
	// e, aqui em "main", escreva um c�digo de TESTE

	std::cout << "-Potencia"  << std::endl;
	for ( n=0; n<5; ++n )
		std::cout << "10 elevado a " << n << " = " <<Potencia(10, n)																   
																					<<std::endl;
	return 0;
}

