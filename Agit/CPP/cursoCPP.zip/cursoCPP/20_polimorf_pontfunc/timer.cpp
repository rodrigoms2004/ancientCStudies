#include <iostream>
#include <ctime>     // fun��es para tempo
#include <cstdlib>
using namespace std;

class Timer
{
	public:
		// ponteiros para fun��es devem amarrar o PROT�TIPO
		// das fun��es esperadas � vari�vel que guardar� seus
		// endere�os.
		// Ent�o para o seguinte prot�tipo de fun��o:
		// bool Funcao( int ) ;
		// teremos a seguinte declara��o de ponteiro:
		bool ( * m_pfTempoDecorrido )( int );

		// OU criando um sin�nimo:
//		typedef bool ( * tpfTempoDec )( int );
//		tpfTempoDec m_pfTempoDecorrido ;
		
		Timer() // construtora
		{
			m_pfTempoDecorrido = NULL;
		}
		void Executa( int nIntervalo ) // segundos
		{
			if ( m_pfTempoDecorrido == NULL ) // ponteiro inv�lido
				return;
				
			int nVezes = 0;
			bool bOK;
			do
			{
				Pausa( nIntervalo );
				++nVezes;
				bOK = m_pfTempoDecorrido(nVezes);

			} while ( bOK );
		}
		void Pausa(int nIntervalo)
		{
			clock_t Inicio = clock();
			clock_t Fim = Inicio + (nIntervalo*CLOCKS_PER_SEC);
			while ( Inicio < Fim )
			{
				Inicio = clock();
			}
		}
};

// ACIMA C�DIGO GEN�RICO P/QUALQUER APLICA��O  /\

// ABAIXO UMA APLICACAO ESPECIFICA  \/


//a fun��o cujo ponteiro ser� passado tem que ser "bool Func(int)"
bool Despertar(int nVezes)
{
	if (nVezes > 5 )
		return false; // interrompe o Timer
	cout << "Despertar: acordei ... trabalhando... " << nVezes << endl;
	return true;
}
int main()
{
	Timer Despertador;
	// para armazenar o ENDERE�O de uma fun��o(e n�o o seu RETORNO)
	// basta N�O colocar os ( ) ap�s o nome da fun��o:
	Despertador.m_pfTempoDecorrido = Despertar ; // sem ( )
	Despertador.Executa( 1 ); // 1 segundo
        std::cin.get();
        return 0;
}

