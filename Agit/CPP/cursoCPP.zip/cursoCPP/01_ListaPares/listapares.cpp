
#include <stdio.h>

int soma ( int a , int b );

int main() 
{
	printf ("Lista de Pares: informe inicial e final\n" );
	int inicial, final;
	
	// entrada de dados pelo teclado:
	int camposLidos = scanf("%d%d", &inicial, &final );
	printf("\n"); // "\n" -> uma quebra de linha ("newline")
	
	//"camposLidos" contem quantos campos "scanf" leu com sucesso
	// mandei que ela lesse 2 ("%d%d") inteiros de base decimal;
	// se houve erro na entrada ela retornar� menor que 2
	if ( camposLidos < 2 )
	{
		printf("dados incorretos\n");
		return 0;
	}
	
/*	// resto da divis�o por 2 � um ?	
	if ( (inicial % 2) == 1 ) // o inicial � �MPAR;
	 	++inicial; // vai para o pr�ximo par.
*/
	// divis�o e resto de divis�o s�o opera��es mais lentas
	//posso simplesmente ler o �ltimo BIT: se 1 � �mpar, zero=par	
//	if ( (inicial & 1) == 1 ) // o inicial � �MPAR;
	if ( inicial & 1 ) // o inicial � �MPAR;
	 	++inicial; // vai para o pr�ximo par.
	
	if ( inicial > final )
	{
		printf ("nenhum numero par no intervalo");
		return 0;
	}
	for ( ; inicial <= final ; inicial+=2 ) //inicial=inicial+2...	
		printf("%d\n" , inicial );

	
	return 0 ;
}
int soma ( int a , int b ) { return a + b ; }

