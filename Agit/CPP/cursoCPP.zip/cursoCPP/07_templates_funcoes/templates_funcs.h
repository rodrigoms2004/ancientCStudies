#ifndef TEMPLATES_FUNCS_H
#define TEMPLATES_FUNCS_H

/*
  usando inlines:  problema:  MESMA L�GICA  (algoritmo)
  para diversos tipos: REPETI��O DE C�DIGO:

inline int Maximo ( int x, int y )
{
    return x > y ? x : y ;
}
inline double Maximo ( double x, double y )
{
    return x > y ? x : y ;
}
inline unsigned int Maximo ( unsigned int x, unsigned int y )
{
    return x > y ? x : y ;
}
*/

/*  // usando MACROS: problemas decorrentes da simples
                                    TROCA DE TEXTO
#define MAXIMO (a,b)  ((a>b)?a:b)
// uso:
  int x, y , z;
  z = MAXIMO(x,y) ;
//  um processamento de texto (pre-compila��o)
  // transforma isso em:
  z = ((x>y)?x:y) ;

  // problema disso:
  z = MAXIMO(++x, y );  // ser� transformado em:
  z = ( (++x>y) ? ++x : y ;
  double d1, d2, d3 ;
  d3 = MAXIMO (sqrt(d1), d2 )  ;
  d3 = ((sqrt(d1)>d2 ? sqrt(d1)  : d2 ) ;
*/

// templates: ABSTRA��O DE TIPO:

/*
?  Maximo (  ? x , ? y)
{
    return x > y ? x : y ;
}
*/
/*
// RESOLVIDO ASSIM:
//          nome do tipo     TIPO do                TIPOS DOS
//          desconhecido     RETORNO             ARGUMENTOS
template <typename T>        T       Maximo (  T  x , T  y  )
{
    return x > y ? x : y ;
}
*/
// mas, neste caso, deveria ser TAMB�M inline
template <typename T> inline T Maximo (  T  x , T  y  )
{
    return x > y ? x : y ;
}

// mais que um argumento template:
template <typename TRet, typename TArg>
        inline TRet Fatorial( TArg num )
{
    TRet result ;
    for ( result = 1 ; num > 1; --num)
        result *= num ;

    return result;
}


#endif // TEMPLATES_FUNCS_H
