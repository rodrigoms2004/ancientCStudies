// diret�rios de include padr�o (<>) s�o informados para o
// compilador:
// -I"..\..\Qt\2010.02\qt\include" -I"..\..\Qt\2010.02\qt\include\ActiveQt" -I"debug" -I"..\..\Qt\2010.02\qt\mkspecs\win32-g++"
#include <iostream>
#include "templates_funcs.h"
#include "../05_dataCPP/cursoData.h"
int main()
{
    int x = 10, y =3 , z ;
    // o tipo parametrizado � deduzido do tipo dos argumentos:
    z = Maximo( x, y );  // ir� criar uma fun��o "Maximo" para int
    double d1=10.1, d2=9, d3;
    d3 = Maximo( d1, d2 );  // ir� criar uma fun��o "Maximo"
                                                // para double
    std::cout << "z = " << z << "\n";
    std::cout << "d3 = " << d3 << "\n";

    // o tipo parametrizado pode ser definido EXPLICITAMENTE
    // (embora n�o seja necess�rio neste caso):
    z = Maximo<int>(x,y);
    d3 = Maximo<double>(d1,d2) ;

    // erro: n�o consegue deduzir o tipo do retorno ("TRet")
    // d3 = Fatorial ( x ) ;
    // obrigatoriamente, tenho que ser expl�cito:
                    //    TRet ,TArg
    d3 = Fatorial<double, int>(x);
    // mas, como o tipo de "x" (int) pode ser deduzido, BASTA:
                    //   TRet
    d3 = Fatorial<double>(x);

    cursoData dt1(10,10,2010);
    cursoData dt2(11,10,2010);
    // caso "cursoData" n�o tivesse o "operator >"
    // a chamada abaixo seria imposs�vel:
    cursoData dt3 = Maximo(dt1,dt2);
    // ter�amos um erro, com uma descri��o como esta:
    // no match for 'operator>' in 'x > y'

    std::cout << "Maior data: " ;
    dt3.Imprime();

    std::cout << "<enter> para sair\n";
    std::cin.get();
    return 0;
}
