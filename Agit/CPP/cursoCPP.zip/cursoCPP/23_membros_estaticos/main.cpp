#include <iostream>
using namespace std;

class Qualquer
{
private:
        int m_x;
        static int m_nTotalObjetos;

        // se for const e num�rico INTEIRO posso inicializar aqui:
        //(muitos compiladores aceitam isso para qualquer num�rico)
                //	static const int m_nVarConst = 0;
        // a linha acima n�o compila no VC6
        // ent�o:
        static const int m_nVarConst = 0;
//	static const int m_nVarConst;

public:
        static int public_static;

        Qualquer() // construtora
                : m_x(0)
        {
                // ERRO: C2166: l-value specifies const object
                // m_nVarConst = 1;  // EST�TICA CONST

                // a vari�vel abaixo � est�tica mas N�O � CONST
                ++m_nTotalObjetos; // OK // EST�TICA

                cout << "construtora: Total Objetos = "
                         << m_nTotalObjetos << endl;

        }
        ~Qualquer() // destrutora
        {
                --m_nTotalObjetos;
                cout << "destrutora: Total Objetos = "
                         << m_nTotalObjetos << endl;
        }
        int GetX() const { return m_x ; }
        void SetX(int x) { m_x = x; }

        // fun��es "static" s� podem acessar membros est�ticos
        // pois n�o recebem o ponteiro "this":
        static int GetTotalObjetos()
        {
                //illegal reference to non-static member 'Qualquer::m_x'
        //	m_x  = 10; // ERRO

                // static member functions do not have 'this' pointers
//	    this->m_x = 10; // MESMO ERRO

                return m_nTotalObjetos;
        }
        static int  GetVarConst( )
        {
                return m_nVarConst;
        }
        static const int & GetRefVarConst( )
        {
                return m_nVarConst;
        }
        static const int * GetPtrVarConst( )
        {
                return &m_nVarConst;
        }
};

 // sempre no ".cpp" :

// est�ticas N�O CONST tem que ser inicializadas
// no escopo global (fora de qualquer fun��o):
int Qualquer::m_nTotalObjetos =0;
int Qualquer::public_static = 100;

// se a est�tica abaixo (CONST)
// n�o foi inicializada
// na pr�pria declara��o da classe, ent�o
// ter� que ser obrigatoriamente inicializada
// no escopo GLOBAL (fora de qualquer fun��o):
// const int Qualquer::m_nVarConst = 0;

int main()
{
        // ainda n�o criei NENHUM objeto do tipo "Qualquer".
        // mas posso acessar os membros est�ticos, porque
        // est�o sempre na mem�ria (tempo de vida global):
        cout << "Qualquer::public_static = "
                << Qualquer::public_static	<< endl;

        cout << "main: valor inicial de TotalObjetos = "
                  << Qualquer::GetTotalObjetos() << endl << endl;

        cout << "GetVarConst: " <<
                                Qualquer::GetVarConst << endl;

        cout << "GetRefVarConst: " <<
                        Qualquer::GetRefVarConst << endl;

        cout << "GetPtrVarConst: " <<
                Qualquer::GetPtrVarConst << endl;
        {
                Qualquer qq_1 ;
                        qq_1.SetX( 1 );
                Qualquer qq_2 ;
                        qq_2.SetX( 2 );

        } // destrutora ser� chamada aqui para qq_2 e qq_1

        // erro: a vari�vel abaixo N�O EXISTE:
        // cout << m_nTotalObjetos << endl;

        // a vari�vel abaixo EXISTE mas ocorrer� erro
        // pois "m_nTotalObjetos" � PRIVATE:
         // cout << Qualquer::m_nTotalObjetos << endl;

        cout << "\n<enter> p/sair\n";
        std::cin.get();
        return 0;
}


/*
Qualquer q1;
q1.m_x=5; // caso fosse p�blico

Qualquer q2;
q2.mx =10; // idem

Qualquer::m_nTotalObjetos = 2 ; // se fosse public...

  |     5        |    |    10     |
  |   m_x      |    |   m_x    |    |      2     | (est�tica!!!)
  |_______ _|    |________|    |________|
      q1                    q2           Qualquer::TotalObjetos


          // pode-se fazer:
          q1.m_nTotalObjetos = ... ;
          q2.m_nTotalObjetos = ....;
   // o que na pr�tica altera sempre uma mesma mem�ria
   // ENT�O � MAIS CLARO:
   Qualquer::m_nTotalObjetos = ... ;

*/
