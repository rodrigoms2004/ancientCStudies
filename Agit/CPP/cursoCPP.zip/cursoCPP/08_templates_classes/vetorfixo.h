
#ifndef VETORFIXO_H
#define VETORFIXO_H
// tudo o que eu escrever aqui s� ser� considerado pelo
// compilador se o s�mbolo VETORFIXO_H N�O ESTIVER definido
// (#ifndef). Isso impede dupla inclus�o, pois se n�o est�
// definido � definido em seguida (#define...)
#include <iostream>

// size_t �, atualmente, um typedef (oficial) para "unsigned int"
template <typename T, size_t Dimension >
class VetorFixo     // "T" : tipo parametrizado;
{                         // "Dimension" : uma constante
    private:
        T m_vetor [ Dimension ] ; // um vetor de "T"
                                // "T" ter� que ser definido ao usar
    public:
        size_t size()const { return Dimension ; }

        // para situa��es onde � prudente uma
        // verifica��o do �ndice:
        T get ( size_t index ) const
        {
            if ( index >= Dimension )
                throw "VetorFixo::get: indice invalido" ; // exception

            return m_vetor[index] ;
        }
        void set (size_t index, T newValue)
        {
            if ( index >= Dimension )
                throw "VetorFixo::set: indice invalido" ; // exception

            m_vetor[index] = newValue ;
        }

        // para situac�es onde a verificac�o de indice
        // n�o � necess�ria:
        // "get":
        const T & operator [] ( size_t indice ) const // "this"const
        {
            return m_vetor[ indice ];
        }
        // "set":
        T & operator [] ( size_t indice )  // "this " n�o const
        {
            return m_vetor[ indice ];
        }
};

#endif // VETORFIXO_H
