#include <iostream>
#include "vetorfixo.h"
int main()
{
    VetorFixo<int,5> vfi;
    // situa��o segura:
    size_t index ;
    int value=100;
    for ( index=0; index<vfi.size(); ++index)
    {
        vfi[index ] = ++value ;
        std::cout << vfi[index] << " , " ;
    }
    std::cout << "\n";

    // criando um sin�nimo para um elemento:
    const int & ref = vfi[ 0 ];
    std::cout << "ref = " << ref  << "\n";

    // situa��o INSEGURA:
    std::cout << "informe indice : " ;
    std::cin >> index ;
    try
    {
        std::cout << "elemento em " << index  << " = "
                        << vfi.get(index) << "\n" ;
    }
    catch ( const char * err)
    {
        std::cout << "Erro: " << err << "\n";
    }

    // outra maneira:
    std::cout << "informe indice : " ;
    std::cin >> index ;
    if ( index < vfi.size() )  // agora � seguro...
        std::cout << "elemento em " << index  << " = "
                        << vfi[ index ] << "\n" ;
    else
        std::cout << "indice incorreto\n" ;

    std::cout << "<enter> p/sair\n";
    std::cin.ignore(0xFFFF, '\n');
    std::cin.get();
    return 0;
}
