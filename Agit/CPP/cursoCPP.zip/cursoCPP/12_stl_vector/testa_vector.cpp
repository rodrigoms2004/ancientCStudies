
#include <iostream>
#include <vector>

int main( )
{
	std::vector< int > vi;
	// fun��o "push_back" EM UM VECTOR:
	// o ideal � usar "reserve" antes!!!
	vi.reserve( 10 );
	vi.push_back( 1 );
	vi.push_back(2);
	vi.push_back(3);
	size_t nInd;
	for ( nInd =0; nInd < vi.size(); ++nInd)
		std::cout << vi[ nInd ] << " , " ;
	std::cout << std::endl;
	
	vi.resize( 5, 9 );
	std::cout << "vi apos resize(5,9)" << std::endl;
	for ( nInd =0; nInd < vi.size(); ++nInd)
		std::cout << vi[ nInd ] << " , ";
	std::cout << std::endl;
	
	vi.assign( 7, 8 );
	std::cout << "vi apos assign(7,8)" << std::endl;
	for ( nInd =0; nInd < vi.size(); ++nInd)
		std::cout << vi[ nInd ]  << " , ";	
	std::cout << std::endl;

        vi[4] = 10;  // operator[] -> n�o verifica �ndice
        vi.at(4) = 10; // "at" verifica �ndice (exception...)
        int i = vi.at(4); // idem

	std::cout << "apos vi[4]=10" << std::endl;
	for ( nInd =0; nInd < vi.size(); ++nInd)
		std::cout << vi[ nInd ]  << " , ";	
	std::cout << std::endl;
	
	vi.reserve(100 ); // reserva, alterando a "capacity"
								// (o mesmo que no projeto STL_String)
	std::cout << "tamanho : " <<vi.size() << std::endl;
	std::cout << "reservado : " <<vi.capacity() << std::endl;
	
	// para navegar, al�m de �ndice, posso usar o ITERATOR:
	std::vector<int>::iterator vIt;
        int n ;
        for ( n=1, vIt = vi.begin(); vIt != vi.end();  ++vIt, ++n )
        {
            *vIt = n ;
            std::cout << *vIt << " , " ;
        }
	std::cout << std::endl;
	
	// ou o "reverse_iterator":
	std::vector<int>::reverse_iterator vRIt;
	for ( vRIt = vi.rbegin(); vRIt != vi.rend();  ++vRIt )
		std::cout << *vRIt << " , " ;
	std::cout << std::endl;

	vIt = vi.begin();
	++vIt;  // inserindo um elemento no meio 
        vi.insert( vIt, 5); //(obriga c�pia para a frente)
        // (menos mal, j� que usei reserve)

	std::vector<int>::const_iterator vCIt;
	for ( vCIt = vi.begin(); vCIt != vi.end();  ++vCIt )
		std::cout << *vCIt << " , " ;
        // aqui eu n�o poderia fazer: *vCIt = n ;

	std::cout << std::endl;

        int tot_rows = 5, tot_cols = 3;

        // vetor de 3 ints:
        std::vector < int > item ( tot_cols, 0) ;
                                    // j� faz o resize (tot_cols, 0 )
        std::vector< std::vector < int > >
                                                    vec2Int (tot_rows, item) ;
                                      // j� faz o resize ( tot_rows, item );
        //vetor de 5 "linhas" ; cada linha tem 3 "colunas"
        // ou seja um vetor de 5 elementos, sendo cada um deles
        // um vetor de inteiros de 3 elementos.

                // que o vetor � indexadoa partir de ZERO (como uma matriz):
        vec2Int[0][0] = 11; // "linha" 1, "coluna" 1
        vec2Int[0][1] = 12; // "linha" 1, "coluna" 2
        vec2Int[0][2] = 13; // "linha" 1, "coluna" 3
        vec2Int[1][0] = 21; // "linha" 2, "coluna" 1
        vec2Int[1][1] = 22; // "linha" 2, "coluna" 2
        vec2Int[1][2] = 23; // "linha" 2, "coluna" 3
        // e etc...
        // agora, imprimir:
        using namespace std;
        for ( size_t row = 0; row < vec2Int.size(); row++)
        {
            for ( size_t col=0 ; col < vec2Int[row].size() ; col++)
            {
               cout.width(3);
               cout << vec2Int[ row ][ col ] << " - ";
            }
            cout << endl;
        }
        /* IMPRIMIU:
        11 -  12 -  13 -
        21 -  22 -  23 -
         0 -   0 -   0 -
         0 -   0 -   0 -
         0 -   0 -   0 -
         */

        std::cout << "<enter> p/sair\n";
        std::cin.get();
	return 0;

}

