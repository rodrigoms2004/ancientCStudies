
#include <iostream>
#include <ctime>     // fun��es para tempo
#include <cstdlib>
using namespace std;

class Timer
{
        public:
                Timer() // construtora
                {
                        // TempoDecorrido(1);
                }
                ~Timer() // destrutora
                {
                        // TempoDecorrido(1);
                }

                // na vers�o anterior t�nhamos:
                /*		virtual bool TempoDecorrido(int nVezes)
                                {
                                        cout << "BASE: passou aqui inutilmente" << endl;
                                        return false;
                                        // mas essa fun��o n�o faz nada...
                                        // ser� que poderia ser eliminada?
                                }
                */
                // como a virtual acima n�o faz nada
                // (n�o tem qualquer a��o "default")
                // ent�o n�s a transformamos em uma VIRTUAL PURA.
                // Uma VIRTUAL PURA n�o � implementada nesta classe;
                // ela garante apenas uma entrada no vetor de ponteiros
                // Mas o endere�o na base � inv�lido e assim
                // s� se pode criar objetos a partir de DERIVADAS.
                // Por isto uma classe que tem uma virtual-PURA
                // � chamada "CLASSE ABSTRATA".
                virtual bool TempoDecorrido(int nVezes) = 0;
                                                                                // = 0; como se fosse endere�o nulo

                void Executa( int nIntervalo ) // segundos
                {
                        int nVezes = 0;
                        bool bOK;
                        do
                        {
                                Pausa( nIntervalo );
                                ++nVezes;
                                bOK = TempoDecorrido(nVezes);
                                // bOK = vtable[ x ]( nVezes );

                        } while ( bOK );
                }
                void Pausa(int nIntervalo)
                {
                        clock_t Inicio = clock();
                        clock_t Fim = Inicio + (nIntervalo*CLOCKS_PER_SEC);
                        while ( Inicio < Fim )
                        {
                                Inicio = clock();
                        }
                }
};
class Despertar : public Timer // derivada de "Timer"
{
public:
        // redefine a VIRTUAL da base:
        bool TempoDecorrido(int nVezes)
        {
                if (nVezes > 5 )
                        return false; // interrompe o Timer
                cout << "DERIVADA: acordei ... trabalhando... " << nVezes << endl;
                return true;
        }
        Despertar()
                // vtable[0] = Despertar::TempoDecorrido
        {
        }
        ~Despertar()
        {
        }
} ;
int main()
{
        Despertar desp; // derivada...
        desp.Executa( 1 ) ;

        cout << "\n<enter> p/sair\n";
        std::cin.get();
        return 0;

        // Ap�s a fun��o virtual TempoDecorrido ter sido declarada
        // como virtual-PURA na class Timer, tornou-se imposs�vel
        // criar objetos dessa classe:
        // AGORA A LINHA ABAIXO ESTARIA ERRADA:

///////	Timer t1; // objeto da classe base
        // erro: fun��o TempoDecorrido foi declarada mas N�O IMPLEMENTADA
        // (indefinida)
        // 'Timer' AGORA, � uma CLASSE ABSTRATA.

/*
error C2259: 'Timer' : cannot instantiate abstract class
        due to following members:
        'bool Timer::TempoDecorrido(int)' : is abstract
       : see declaration of 'Timer::TempoDecorrido'
*/
}



