#include <iostream>
#include <string>
#include <set>
#include <map>

/*
                 Este exerc�cio explora "std::set<>" e "std::map<>" que encapsulam uma �rvore-bin�ria de qualquer tipo alocada dinamicamente no "heap",
                 cuidando das necessidades de aloca��o, realoca��o e libera��o de mem�ria de modo seguro e garantido.

                Este exerc�cio permitir� tamb�m observar a import�ncia de "operators" quando trabalhamos com certos templates.
                Um template pode ser instanciado para todos os tipos que satisfa�am seus requisitos.
                Cada inst�ncia n�o necessariamente ter� todas as fun��es definidas no template.
                Ter� apenas aquelas fun��es que foram usadas para aquele tipo.

                No caso de "std::set<>" e "std::map<>",  conseguimos instanciar qualquer tipo.

                Mas N�O � poss�vel sequer inserir elementos nesses "containers", pois a fun��o "insert" (que insere elementos)
                necessita ou do "operator <" ("less") ou do "operator >" ("greater").

                Isto porque uma �rvore-bin�ria tem que estar permanentemente classificada (logo, na inser��o j� s�o feitas compara��es).

                Assim sendo, estes dois "containers" s� fazem sentido para tipo classific�veis,
                que tenham pelo menos um dos operadores relacionais necess�rios.

*/

// ====== Inicialmente, criamos duas classes que permitir�o observar o que o compilador far� quando usarmos "insert":


// === a class "NaoClassificavel" NAO TEM operadores relacionais
class NaoClassificavel
{
                int m_x;
        public:
                NaoClassificavel() { m_x = 0 ;}
                NaoClassificavel(int x) { setX( x) ; }
                int getX () const { return m_x ; }
                void setX( int x) { m_x = x; }
} ;

// === a class "Classificavel" TEM o operador relacional "operator <"
class Classificavel
{
                int m_x;
        public:
                Classificavel() { m_x = 0 ;}
                Classificavel(int x) { setX( x) ; }
                int getX () const { return m_x ; }
                void setX( int x) { m_x = x; }

                // *** "operator <" - isto far� diferen�a...
                bool operator < (const Classificavel & p2) const
                {
                        return this->m_x < p2.m_x;
                }
} ;

int main()
{
        std::cout << "**** TESTANDO 'SET' \n";

        // set: CHAVE �NICA;
        // multiset: permite m�ltiplas ocorr�ncias da chave
        // std::multiset < int > si; // o resto do c�digo fica igual

        // === cria uma inst�ncia de 'std::set<>' para o tipo 'int'

        std::set < int > si;
        std::set < int >::iterator siIt;   // 'iterator' para essa inst�ncia
        std::set < int >::reverse_iterator siRIt;   // 'reverse_iterator' para essa inst�ncia

        // === insere elementos com 'insert':

        si.insert( 3 );
        si.insert( 2 );
        si.insert( 1 );

        std::cout << "percorrendo 'si' ('std::set< int >') usando um 'iterator' \n" ;
        for ( siIt = si.begin(); siIt != si.end(); ++siIt )
                std::cout << *siIt << " , ";

        std::cout << "\n\n";

        // === buscando um elemento com "find":

        siIt = si.find(2);  // 'find'

        if ( siIt == si.end() )  // se n�o encontrou, o 'iterator' aponta para o 'end' (posi��o inv�lida)
                std::cout << "find: nao localizei '2' \n";
        else
                std::cout << "find: localizei: " << *siIt << '\n';

        std::cout << '\n';

        // === buscando um elemento com "erase":

        si.erase(2);
        std::cout << "percorrendo 'si' ('std::set< int >') apos 'erase(2)' \n" ;
        for ( siIt = si.begin(); siIt != si.end(); ++siIt )
                std::cout << *siIt << " , ";

        std::cout << "\n\n";

        // === volta a inserir o inteiro 2:

        si.insert(2);

        std::cout << "percorrendo 'si' ('std::set< int >') apos 'insert (2)' - usando um 'reverse_iterator' \n" ;
        for ( siRIt = si.rbegin(); siRIt != si.rend(); ++siRIt )
                std::cout << *siRIt << " , ";

        std::cout << "\n\n";

        // === eliminado todos os elementos:

        std::cout << "tamanho atual de 'si' = " << si.size() << '\n';
        si.clear(); // elimina todos
        // clear, corresponde a
        // si.erase(si.begin(), si.end());

        std::cout << "tamanho de 'si' apos 'clear' = " << si.size() << '\n';

        std::cout << '\n';

        // === testando 'std::set<>' com a classe 'Classificavel' :

        std::set< Classificavel > sCla;  // inst�ncia de 'std::set<>' para a classe 'Classificavel'
        std::set< Classificavel >::iterator sClaIt;   // 'iterator' para essa inst�ncia

        // === insere elementos com 'insert':

        sCla.insert( Classificavel(3) );
        sCla.insert( Classificavel(2) );
        sCla.insert( Classificavel(1) );

        std::cout << "percorrendo 'sCla' ('std::set<Classificavel>')  - usando um 'iterator' \n" ;
        for ( sClaIt = sCla.begin(); sClaIt != sCla.end(); ++sClaIt)
                std::cout << sClaIt->getX() << " ,  " ;

        std::cout << "\n\n";

        // === testando 'std::set<>' com a classe 'NaoClassificavel' :

        std::set < NaoClassificavel > sNCla;  // consigo instanciar 'std::set<>' para 'NaoClassificavel' ...

        // = mas n�o consigo fazer mais nada: sequer inserir elementos:

// sNCla.insert( NaoClassificavel ( 10 ) ); // ERRO ! opera��o imposs�vel, pois 'NaoClassificavel' N�O TEM o 'operator <'

                std::cout << "nao consigo inserir elementos em 'std::set<NaoClassificavel' ";

                std::cout << "\n\n";

        // ======== utilizando std::map<>

        std::cout << "\n**** TESTANDO 'MAP' \n\n";

        // TESTANDO MAP
        // map: chave �NICA;
        // multimap: chave com m�ltiplas ocorr�ncias

        // === OBS: ao contr�rio de 'std::set<>' que tem apenas um tipo-parametrizado para seus elementos,
   //						'std::map' utiliza dois tipos-parametrizados: um para a chave, outro para um valor associado a essa chave.

                  // chave, valor associado
        std::map < int , std::string > mis;
        // inst�ncia de 'std::map<>' onde a chave � um 'int'
        // e o valor associado � uma 'string'
        std::map < int , std::string >::iterator misIt;  // 'iterator para essa inst�ncia'

        // OBS:
        // "chave" tem que suportar opera��o 'menor que' (se 'less') ou "maior que" (se 'greater')
        // j� "valor associado" n�o precisa disso

        // === inserindo elementos com insert:

        mis.insert( std::map<int,std::string>::value_type (3, "terceiro") );
        mis.insert( std::map<int,std::string>::value_type (2, "segundo") );
        mis.insert( std::map<int,std::string>::value_type (1, "primeiro") );
        // OBS: o "value_type" � um tipo aninhado que forma um "par" ("std::pair"), de modo a agrupar "chave" e "valor-associado"

        std::cout << "percorrendo 'mis' ('std::map<int,std::string>') \n";
        for ( misIt = mis.begin(); misIt != mis.end(); ++misIt )
                std::cout << misIt->first << " - "
                                    << misIt->second << '\n';
        // OBS: o 'iterator' 'misIt' aponta para um "pair" :
        // "first" � a chave e "second" � o valor-associado

        std::cout << '\n';

        // === uma boa id�ia seria usar typedef
        // para simplificar escrita...

        // = cria sin�nimos simplificadores:
        typedef std::map < int , std::string > mapIntStr_t;
        typedef mapIntStr_t::iterator mapIntStrIT_t;
        typedef mapIntStr_t::value_type mapIntStrVT_t;

        // e usa esses sin�nimos para criar inst�ncias e seus 'iterator's:
        mapIntStr_t mis2;
        mapIntStrIT_t misIt2;

        // === inserindo com 'insert', usando os sin�nimos de tipo:

        mis2.insert( mapIntStrVT_t( 3, "terceiro"));
        mis2.insert( mapIntStrVT_t( 2, "segundo"));
        mis2.insert( mapIntStrVT_t( 1, "primeiro"));

        std::cout << "percorrendo 'mis2' (declarado com o sin�nimo 'mapIntStr_t') \n";
        for ( misIt2 = mis2.begin(); misIt2 != mis2.end(); ++misIt2 )
                std::cout << misIt2->first << " - "
                        << misIt2->second << '\n';

        std::cout << '\n';

        // === buscando um elemento com 'find':

        misIt = mis.find( 2 );

        if ( misIt == mis.end() )  // se n�o achou, o 'iterator' aponta para 'end' (elemento inv�lido)
                std::cout << "find: nao localizou '2' \n" ;
        else
                std::cout << "find: " << misIt->first <<" - "
                                    << misIt->second << '\n';

        std::cout << '\n';

        // === eliminando um elemento com 'erase':

        mis.erase(2 );

        std::cout << "percorrendo 'mis' ('std::map<int,std::string>') apos 'erase(2)' \n";
        for ( misIt = mis.begin(); misIt != mis.end(); ++misIt )
                std::cout << misIt->first << " - " << misIt->second << '\n';

        std::cout << '\n';

        std::cout << "tamanho atual de 'mis' :  " << mis.size() << '\n';
        mis.clear(); // elimina todos os elementos
        std::cout << "tamanho de 'mis' apos clear:  " << mis.size() << '\n' ;

        std::cout << '\n' << std::endl;

        std::cout << "<enter> p/sair\n";
        std::cin.get();

        return 0;
}
// std::map < int, std::list< std::string > > mapRank;
// a chave e um int e o valor associado
// � uma lista ligada de strings.

