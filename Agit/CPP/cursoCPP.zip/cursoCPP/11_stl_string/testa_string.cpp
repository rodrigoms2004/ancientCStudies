
#include <iostream>
#include <string>
#include <sstream> // string stream
#include <iomanip> // width, precision, etc..

int main()
{
	std::string str;
	str = "Maria";
	std::cout << "str apos str='Maria' = " << str << std::endl;
	str += " da Silva";
	std::cout<<"str apos str+='da Silva' = "<< str<<std::endl;
	
	std::string str2;
        // dica de performance:
        // ao inv�s de:
        str2 = str + " Aparecida";
        // melhor (em termos de performance):
        str2 = str;
        str2 += " Aparecida";

        std::cout<<"str2 apos str2 = str + 'Aparecida' = "
																	<< str2<<std::endl;
	std::cout<<"tamanho de str = "<<str.length()<<std::endl;
        std::cout<<"tamanho de str2= "<<str2.length()<<std::endl;

        // size_t � um typedef para unsigned int
        size_t pos;                //0123456
        pos = str.find("da");  // Maria  da Silva
	if ( pos == std::string::npos )// <-"npos" = NULL POSITION
		std::cout << "str nao contem 'da'" << std:: endl;
	else
                std::cout << "localizei 'da' em str na posicao = "
                                                          << pos << std::endl;

	std::cout << "maior string possivel = " 
                                <<	str.max_size() << std::endl;

        str.erase(); // "limpa"
	if ( str.empty() )
		std::cout << "erase funcionou!" << std::endl;
	else
		std::cout << "erase falhou???" << std::endl;
	str.resize(4);
	str[0] = 'A';
	str[1] = 'B';
	str[2] = 'C';
        // str[3] = 0;
	std::cout << "str apos uso do operator [] = "
                                                        << str << std::endl;
	pos = str2.find("da ");
	if ( pos != std::string::npos )
		str2.replace(  pos, 3, "" ); // troca "da " por nada...
	
	std::cout << "str2 apos replace = " << str2 << std::endl;

	pos = str2.find("Silva");
	if ( pos != std::string::npos )
		str2.insert( pos, "da "); 

	std::cout << "str2 apos insert = " << str2 << std::endl;

	str = str2.substr( pos );
	std::cout << "str2.substr(pos) = " << str << std::endl;

	str = str2.substr( pos, 8 );
	std::cout << "str2.substr(pos,8) = " << str << std::endl;

	if ( str == str2 ) // todos os 6 operadores relacionais...
		std::cout << "strings iguais" << std::endl;
	else
		std::cout << "strings diferentes" << std::endl;
	
	str.reserve(100); // reserva sem mudar j� o tamanho
                        // �til para evitar "resizes" in�teis.

	std::cout << "tamanho ALOCADO : " << str.size() 
                                                        << std::endl;
	std::cout << "tamanho RESERVADO : " << str.capacity()
                                                                << std::endl;
	std::cout << "tamanho da string EM USO : "<< str.length()
                                                                << std::endl;

        str.resize(20);
        str[0]='A';
        str[1]='B';
        std::cout << "apos resize(20) e uso de 2 elementos:\n";
        std::cout << "tamanho ALOCADO : " << str.size()
                                                        << std::endl;
        std::cout << "tamanho da string EM USO : "<< str.length()
                                                                << std::endl;

        str = "AB";
        std::cout << "apos str=AB:\n";
        std::cout << "tamanho ALOCADO : " << str.size()
                                                        << std::endl;
        std::cout << "tamanho da string EM USO : "
                << str.length() << std::endl;

        std::cout << "usando stringstream\n";
        std::ostringstream os;
        os << " dolar:  " << 1.70 << " e o euro " << 3.10 ;
        std::cout << os.str() << "\n";
        os.str("");
        os << "128 em hexa " << std::hex << 128 ;
        std::cout << os.str() << "\n";
        os.str("");

        os << std::setw(12) << std::setprecision(5)
                                                       << 23.4359494949 ;
        // imprimir�: <brancos at� width>23.436
        // (o 5 de precision considera tamb�m a parte inteira)
        std::cout << os.str() << "\n";

        // os.width(12);
        // os.precision(5);

        // os.str(""); // para "limpar". OU:.
        os.seekp(std::ios::beg); // posiciona o stream no in�cio
        os << std::setw(12) << std::fixed
                    << std::setprecision(3)  << 23.4359494949 ;
        // imprimir�: <brancos at� width>23.436
        // (o 3 de precision refere-se apenas aos decimais)
        std::cout << os.str() << "\n";

        std::cout << "<enter> p/sair\n";
        std::cin.get();
	return 0;
}
