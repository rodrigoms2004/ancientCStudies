#include <iostream>
using namespace std;

// esta classe visa apenas servir de exemplo de uso
// do template <> class SmartPtr
class Recordset
{
	public:
		bool Open()
		{
			cout << "Recordset::Open" << endl;
			return true;
		}
} ;

template <typename T> class SmartPtr
{
	private:
		T * m_p;
	public:
		SmartPtr() { m_p = NULL; }
		~SmartPtr() {
			if ( m_p != NULL ) 
			{
				delete m_p; 
				m_p = NULL;
			}
		}
		bool CreateInstance() { 
			if ( m_p!=NULL )
				delete m_p;
			m_p = new T; 
			return m_p != NULL;
		}
		T * operator ->() { 
			return m_p;
		}
		T &operator * () 
		{
			return * m_p;
		}
} ;
int
main()
{
    // typedef apenas para simplificar:
	typedef SmartPtr< Recordset > _RecordsetPtr;
	
		_RecordsetPtr pRS;
		pRS.CreateInstance();
		pRS->Open(); // <<< m_p->Open();
		
		// poderia...
		Recordset & rRS = *pRS; // uma refer�ncia para o objeto
												 // apontado por SmartPtr<>::m_p
		// e AT� poderia:
		Recordset RS = *pRS; // uma c�pia completa do objeto
											// apontado por SmartPtr<>::m_p
											
	return 0; // destrutora para pRS ser� chamada aqui....
					// e a mem�ria apontada por SmartPtr<>::m_p
					// ser� liberada...
}
