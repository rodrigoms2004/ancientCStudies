
#include <iostream>
#include <list>
#include "../05_dataCPP/cursoData.h"


class Qualquer
{
	int m_x;
public:
	Qualquer() { m_x = 0 ;}
	Qualquer(int x) { SetX( x) ; }
	int GetX () const { return m_x ; }
	void SetX( int x) { m_x = x; }
} ;
class QualquerClassificavel
{
	int m_x;
public:
	QualquerClassificavel() { m_x = 0 ;}
	QualquerClassificavel(int x) { SetX( x) ; }
	int GetX () const { return m_x ; }
	void SetX( int x) { m_x = x; }
	bool operator < (const QualquerClassificavel & p2) const
	{
		return this->m_x < p2.m_x;
	}
} ;

int main()
{
	std::list< int > li;
	std::list< int >::iterator liIt;
	std::list< int >::reverse_iterator liRIt;

	// inserindo no fim:
	li.push_back( 1 );
	li.push_back( 2 );
	li.push_back( 3 );

	for ( liIt = li.begin(); liIt != li.end(); ++liIt )
		std::cout <<  *liIt << " , ";
	std::cout << std::endl;
	for ( liRIt = li.rbegin(); liRIt != li.rend(); ++liRIt )
		std::cout <<  *liRIt << " , ";
	std::cout << std::endl;

	// inserindo no in�cio:
	li.push_front( 4 );
	li.push_front( 5 );
	li.push_front( 6 );
	for ( liIt = li.begin(); liIt != li.end(); ++liIt )
		std::cout <<  *liIt << " , ";
	std::cout << std::endl;

	li.sort();
	std::cout<< "apos sort" <<std::endl;
	for ( liIt = li.begin(); liIt != li.end(); ++liIt )
		std::cout <<  *liIt << " , ";
	std::cout << std::endl;

	// inserindo no meio:
	liIt = li.begin();
	++liIt; ++liIt; // atingi terceiro elemento
	li.insert( liIt , 10 );
	std::cout<< "apos insert(liIt, 10)" <<std::endl;
	for ( liIt = li.begin(); liIt != li.end(); ++liIt )
		std::cout <<  *liIt << " , ";
	std::cout << std::endl;

	// eliminando:
	liIt = li.begin();
	++liIt; ++liIt; ++liIt; // atingi quarto elemento
	liIt = li.erase(liIt ); // elimina esse elemento
	std::cout<< "apos erase(liIt)" <<std::endl;
	std::cout << *liIt << std::endl;
	for ( liIt = li.begin(); liIt != li.end(); ++liIt )
		std::cout <<  *liIt << " , ";
	std::cout << std::endl;
	
	std::cout << "tamanho da list :" << li.size() << std::endl;
	li.clear() ; // elimina todos os elementos
	std::cout << "tamanho da list  apos clear:" << li.size() 
																			<< std::endl;

        std::list< cursoData > ldt;
        std::list< cursoData >::iterator ldtIt;

        cursoData dtTemp;
        dtTemp.Altera(21, 2, 2005);
        ldt.push_back ( dtTemp );
        ldt.push_back( cursoData(2,1,2004) );

        for ( ldtIt = ldt.begin() ; ldtIt != ldt.end() ; ++ldtIt )
                ldtIt->Imprime();

        ldt.sort(); //<- poss�vel pois "cursoData" tem o
                                                        // "operator <"
        std::cout << "apos sort:" << std::endl;
        for ( ldtIt = ldt.begin() ; ldtIt != ldt.end() ; ++ldtIt )
                ldtIt->Imprime();

	std::list < Qualquer > lqq;
	std::list < Qualquer >::iterator lqqIt ;
	lqq.push_back( Qualquer( 3 ) );
	lqq.push_back( Qualquer( 2 ) );
	lqq.push_back( Qualquer( 1 ) );
	for ( lqqIt = lqq.begin(); lqqIt != lqq.end() ; ++lqqIt )
		std::cout << lqqIt->GetX() << std::endl;

//	lqq.sort() ; //<- Erro: imposs�vel, pois "Qualquer" 
						// N�O TEM o 'operator <'

	std::list < QualquerClassificavel > lqqc;
	std::list < QualquerClassificavel >::iterator lqqcIt ;
	lqqc.push_back( QualquerClassificavel( 3 ) );
	lqqc.push_back( QualquerClassificavel( 2 ) );
	lqqc.push_back( QualquerClassificavel( 1 ) );
	for ( lqqcIt = lqqc.begin(); lqqcIt != lqqc.end() ; ++lqqcIt )
		std::cout << lqqcIt->GetX() << std::endl;

	lqqc.sort();//OK! "QualquerClassificavel" TEM o 'operator <'

	std::cout << "lqqc apos sort" << std::endl;
	for ( lqqcIt = lqqc.begin(); lqqcIt != lqqc.end() ; ++lqqcIt )
		std::cout << lqqcIt->GetX() << std::endl;

        std::cout << "<enter> p/sair\n";
        std::cin.get();
        return 0;
}

